import urllib.request
from bs4 import BeautifulSoup
dictionary = {}
flag = 1
for i in range(11000, 12000):
    dictionary['id'] = str(i)
    #print(dictionary['id'])
    url_values = urllib.parse.urlencode(dictionary)
    url = "http://www.joyokids.com/bookinfo.aspx?"
    full_url = url+url_values
    #print(full_url)
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:23.0) Gecko/20100101 Firefox/23.0'}
    req = urllib.request.Request(url=full_url, headers=headers)
    data = urllib.request.urlopen(req).read()
    data = data.decode('GBK')
    soup = BeautifulSoup(data)
    title = soup("title")
    print(title)
    flag += 1
    if flag % 20 == 0:
        dictionary.clear()
        print('wow!')
        print(i)


