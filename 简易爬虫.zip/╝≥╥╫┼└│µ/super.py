import urllib.request
from bs4 import BeautifulSoup
import tablib

dictionary = {}
flag = 1
pa = []
headers = ('书名', 'ISBN', '作者', '类型', '年龄', '页码', '版面', '主题', '系列', '简介')
pa = tablib.Dataset(*pa, headers=headers)
for i in range(3552, 3816):#5163

    dictionary['id'] = str(i)
    # print(dictionary['id'])
    url_values = urllib.parse.urlencode(dictionary)
    url = "http://www.joyokids.com/bookinfo.aspx?"
    full_url = url + url_values
    # print(full_url)
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:23.0) Gecko/20100101 Firefox/23.0'}
    req = urllib.request.Request(url=full_url, headers=headers)
    data = urllib.request.urlopen(req).read()
    data = data.decode('GBK')
    soup = BeautifulSoup(data, 'html.parser')
    title = soup.find('title').string
    isbn1 = soup.find(id='DataList1_Label9_0')  # book isbn
    if isbn1 is not None:
        isbn = isbn1.string
    else:
        isbn = ''
    writer1 = soup.find(id='DataList1_Label5_0')  # book writer作者
    if writer1 is not None:
        writer = writer1.string
    else:
        writer = ''
    kind1 = soup.find(id='DataList1_Label17_0')  # type of book类型
    if kind1 is not None:
        kind = kind1.string
    else:
        kind = ''
    age1 = soup.find(id='DataList1_Label19_0')  # age年龄段
    if age1 is not None:
        age = age1.string
    else:
        age = ''
    pages1 = soup.find(id='DataList1_Label24_0')  # total pages页码
    if pages1 is not None:
        pages = pages1.string
    else:
        pages = ''
    banmian1 = soup.find(id='DataList1_Label40_0')  # 版面
    if banmian1 is not None:
        banmian = banmian1.string
    else:
        banmian = ''
    theme1 = soup.find(id='DataList1_Label26_0')  # the theme of the book
    if theme1 is not None:
        theme = theme1.string
    else:
        theme = ''
    series1 = soup.find(id='DataList1_Label28_0')  # belong to whick series
    if series1 is not None:
        series = series1.string
    else:
        series = ''
    content_into1 = soup.find(id='DataList1_Label22_0')  # 内容简介
    if content_into1 is not None:
        content_into = content_into1.string
    else:
        content_into = ''
    # 增加行
    pa.append([title, isbn, writer, kind, age, pages, banmian, theme, series, content_into])
    with open('f:/test/eighth.xlsx', 'wb') as f:
        f.write(pa.xlsx)
        f.close()
    flag += 1
    print(i)
    if flag % 20 == 0:
        dictionary.clear()
        print('wow!')
