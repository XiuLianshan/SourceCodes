import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.care.bean.KlBean;
import com.care.bean.MsgTitleBean;
import com.care.dao.OpMessageTitle;
import com.care.dao.queryContact;

public class TitleServlet extends HttpServlet {

    /**
     * The doGet method of the servlet. <br>
     * <p>
     * This method is called when a form has its tag value method equals to get.
     *
     * @param request  the request send by the client to the server
     * @param response the response send by the server to the client
     * @throws ServletException if an error occurred
     * @throws IOException      if an error occurred
     */
    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html;charset=utf-8");
        request.setCharacterEncoding("utf-8");
        //request.getRequestDispatcher("/index.jsp").forward(request, response);
    }

    /**
     * The doPost method of the servlet. <br>
     * <p>
     * This method is called when a form has its tag value method equals to
     * post.
     *
     * @param request  the request send by the client to the server
     * @param response the response send by the server to the client
     * @throws ServletException if an error occurred
     * @throws IOException      if an error occurred
     */
    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        doGet(request, response);
        request.setCharacterEncoding("UTF-8");

        String text_title = request.getParameter("text_title");//get parameter text_title
        //System.out.println(text_title);


        OpMessageTitle.addMsgTitle(text_title);//add title
        //System.out.println(text_title);
        List<MsgTitleBean> msg = new ArrayList<MsgTitleBean>();
        msg = OpMessageTitle.queryTitle();
        //	String m=msg.get(0).getTitleName();
        List<String> m = new ArrayList<String>();
        for (MsgTitleBean m1 : msg) {
            m.add(m1.getTitleName());
        }
        request.getSession().setAttribute("t_title", m);
        //System.out.println("fuck");
        //	System.out.println(m);
        List<KlBean> klb = new ArrayList<KlBean>();
        klb = queryContact.queryAll();
        request.getSession().setAttribute("ss", klb);
        request.getRequestDispatcher("/index1.jsp").forward(request, response);

    }

}
