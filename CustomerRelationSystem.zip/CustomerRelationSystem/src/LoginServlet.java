import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

import javax.security.auth.Refreshable;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.care.bean.KlBean;
import com.care.bean.MsgTitleBean;
import com.care.bean.PersonBean;
import com.care.dao.ConnectDatabase;
import com.care.dao.DataGet;
import com.care.dao.OpMessageTitle;
import com.care.dao.queryContact;

public class LoginServlet extends HttpServlet {// 登陆处理的servlet

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {


        List<MsgTitleBean> msg = new ArrayList<MsgTitleBean>();
        msg = OpMessageTitle.queryTitle();
        //	String m=msg.get(0).getTitleName();
        List<String> m = new ArrayList<String>();
        for (MsgTitleBean m1 : msg) {
            m.add(m1.getTitleName());
        }
        request.getSession().setAttribute("t_title", m);
        //System.out.println("fuck");
        //	System.out.println(m);
        List<KlBean> klb = new ArrayList<KlBean>();
        klb = queryContact.queryAll();
        request.getSession().setAttribute("ss", klb);


    }

    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
        request.setCharacterEncoding("UTF-8");
        String login = request.getParameter("login");
        String pswd = request.getParameter("password");

        if (login.equals("xiu") && pswd.equals("123")) {
            // response.getWriter().write("sss");
            request.getRequestDispatcher("/index.jsp").forward(request, response);
            //response.sendRedirect("/CustomerRelationSystem/index.jsp");
        } else {
            response.getWriter().write("wrong information");
            // JOptionPane.showMessageDialog(null, "name doesnot exits");
            response.setHeader("refresh",
                    "2;URL='/CustomerRelationSystem/welcome.jsp'");
            // request.getRequestDispatcher("/CustomerRelationSystem/welcome.jsp");
        }

    }

}
