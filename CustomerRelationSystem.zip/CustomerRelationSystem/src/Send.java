import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.care.bean.HyBean;
import com.care.bean.KlBean;
import com.care.bean.MsgBean;
import com.care.bean.MsgTitleBean;
import com.care.bean.SendMessage;
import com.care.dao.InsertMessage;
import com.care.dao.OpMessageTitle;
import com.care.dao.queryContact;
import com.care.dao.queryHeYueContact;

public class Send extends HttpServlet {

    /**
     * The doGet method of the servlet. <br>
     * <p>
     * This method is called when a form has its tag value method equals to get.
     *
     * @param request  the request send by the client to the server
     * @param response the response send by the server to the client
     * @throws ServletException if an error occurred
     * @throws IOException      if an error occurred
     */
    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=utf-8");
        String receiver = request.getParameter("telephone");
        String theme = request.getParameter("mesg");
        //response.getWriter().write(receiver + " ");
        //response.getWriter().write("发送成功!");
        SendMessage.send(receiver, theme);
        String title = request.getParameter("tttt");

        List<KlBean> kk = queryContact.queryPersonByTel(receiver);// 客历发送录入
        List<HyBean> hh = queryHeYueContact.queryaHyByTel(receiver);
        Iterator it = kk.iterator();
        Iterator its = hh.iterator();
        if (it.hasNext()) {
            String name = kk.get(0).getName();
            MsgBean ms = new MsgBean();
            ms.setMsgContent(theme);
            ms.setMsgReceiver(name);
            ms.setMsgTel(receiver);
            ms.setMsgTitle(title);

            List<MsgBean> list = new ArrayList<MsgBean>();
            list.add(ms);
            System.out.println(theme);
            InsertMessage.insertMsg(list, "客历");
        } else if (its.hasNext()) {
            String _name = hh.get(0).getName();
            MsgBean mg = new MsgBean();
            mg.setMsgContent(theme);
            mg.setMsgReceiver(_name);
            mg.setMsgTel(receiver);
            mg.setMsgTitle(title);

            List<MsgBean> list1 = new ArrayList<MsgBean>();
            list1.add(mg);
            System.out.println("sbsbsbsbsbsb");
            System.out.println(theme);

            InsertMessage.insertMsg(list1, "合约公司");
        }

        //System.out.println("here");

		/*// 合约公司发送录入
        List<HyBean> hh = queryHeYueContact.queryaHyByTel(receiver);
		if(hh == null) {
			System.out.println("ok");
		}
		else {
			System.out.println("buok");
		}
		String _name = hh.get(0).getName();
		MsgBean mg = new MsgBean();
		mg.setMsgContent(theme);
		mg.setMsgReceiver(name);
		mg.setMsgTel(receiver);
		mg.setMsgTitle(title);

		List<MsgBean> list1 = new ArrayList<MsgBean>();
		list1.add(mg);
		System.out.println("sbsbsbsbsbsb");
		System.out.println(theme);

		InsertMessage.insertMsg(list1, "合约公司");*/

        List<MsgTitleBean> msg = new ArrayList<MsgTitleBean>();
        msg = OpMessageTitle.queryTitle();
        // String m=msg.get(0).getTitleName();
        List<String> m = new ArrayList<String>();
        for (MsgTitleBean m1 : msg) {
            m.add(m1.getTitleName());
        }
        request.getSession().setAttribute("t_title", m);
        // System.out.println("fuck");
        // System.out.println(m);
        List<KlBean> klb = new ArrayList<KlBean>();
        klb = queryContact.queryAll();
        request.getSession().setAttribute("ss", klb);

        request.getRequestDispatcher("/index3.jsp").forward(request, response);
    }

    /**
     * The doPost method of the servlet. <br>
     * <p>
     * This method is called when a form has its tag value method equals to
     * post.
     *
     * @param request  the request send by the client to the server
     * @param response the response send by the server to the client
     * @throws ServletException if an error occurred
     * @throws IOException      if an error occurred
     */
    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);

    }

}
