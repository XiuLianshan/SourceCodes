import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.care.bean.KlBean;
import com.care.bean.MessageBean;
import com.care.bean.MsgTitleBean;
import com.care.dao.InsertMessage;
import com.care.dao.OpMessageTitle;
import com.care.dao.queryContact;

public class ContentQuery extends HttpServlet {

    /**
     * The doGet method of the servlet. <br>
     * <p>
     * This method is called when a form has its tag value method equals to get.
     *
     * @param request  the request send by the client to the server
     * @param response the response send by the server to the client
     * @throws ServletException if an error occurred
     * @throws IOException      if an error occurred
     */
    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

    }

    /**
     * The doPost method of the servlet. <br>
     * <p>
     * This method is called when a form has its tag value method equals to
     * post.
     *
     * @param request  the request send by the client to the server
     * @param response the response send by the server to the client
     * @throws ServletException if an error occurred
     * @throws IOException      if an error occurred
     */
    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        // response.setCharacterEncoding("UTF-8");

        String hk_type = request.getParameter("hk_type"); // 客户类型
        String dxbt = request.getParameter("dxbt"); // 短信标题
        String hydw = request.getParameter("hydw");
        String phydw = request.getParameter("phydw");
        String gsdb = request.getParameter("gsdb");
        String pgsdb = request.getParameter("pgsdb");
        String fszt = request.getParameter("fszt");
        String pfszt = request.getParameter("ss");
        String fsnr = request.getParameter("fsnr");
        String pfsnr = request.getParameter("pfsnr");
        List<MessageBean> message = new ArrayList<MessageBean>();
        /*
		 * if (hk_type == null && dxbt == null && hydw == null && gsdb == null
		 * && fszt == null && fsnr == null) { message =
		 * InsertMessage.queryAllInfo(); } else { if (hk_type == "kl" && dxbt ==
		 * null && hydw == null && gsdb == null && fszt == null && fsnr == null)
		 * { message = InsertMessage.queryMsgByType("客历"); } if (hk_type == "hy"
		 * && dxbt == null && hydw == null && gsdb == null && fszt == null &&
		 * fsnr == null) { message = InsertMessage.queryMsgByType("合约公司"); }
		 * 
		 * List<MsgTitleBean> msg1 = new ArrayList<MsgTitleBean>(); msg1 =
		 * OpMessageTitle.queryTitle(); for (MsgTitleBean m2 : msg1) { if
		 * (m2.getTitleName().equals(dxbt)) ; { message =
		 * InsertMessage.queryMsgByTitle(dxbt); } } if (hydw != null && phydw !=
		 * null) {
		 * 
		 * } if (gsdb != null && pgsdb != null) { if (hk_type == "kl" && dxbt ==
		 * null && hydw == null && gsdb == null && fszt == null && fsnr == null)
		 * { message = InsertMessage.queryMsgByName(pgsdb); } if (hk_type ==
		 * "hy" && dxbt == null && hydw == null && gsdb == null && fszt == null
		 * && fsnr == null) { message = InsertMessage.queryMsgByHyName(pgsdb); }
		 * } if (fszt != null && pfszt != null) { if (pfszt.equals("yes")) { }
		 * if (pfszt.equals("no")) { } if (pfszt.equals("fail")) { } }
		 * 
		 * }
		 */
		/*
		 * if ( hydw == null && gsdb == null && fszt == null && fsnr == null) {
		 * message = InsertMessage.queryAllInfo(); }
		 */
        if (hk_type.equals("kl"))// 按合约类型 客历查询

        {
            message = InsertMessage.queryMsgByType("客历");

            System.out.println(message.get(0).getName());
        }
        if (hk_type.equals("hy"))// 按合约类型合约公司查询

        {
            message = InsertMessage.queryMsgByType("合约公司");
            System.out.println("buyao的");
        }
        // 按短信标题查询

        List<MsgTitleBean> msg1 = new ArrayList<MsgTitleBean>();
        msg1 = OpMessageTitle.queryTitle();
        for (MsgTitleBean m2 : msg1) {
            if (m2.getTitleName().equals(dxbt))

            {
                System.out.println("asde");
                message = InsertMessage.queryMsgByTitle(dxbt);
            }
        }

        // 按合约单位查询
        if (hydw != null && phydw != null) {
            message = InsertMessage.queryMsgByHyName(phydw);
        }
        // 按照姓名
        if (gsdb != null && pgsdb != null) {
            System.out.println(pgsdb);
            message = InsertMessage.queryMsgByName(pgsdb);

        }
        request.getSession().setAttribute("message", message);
        List<MsgTitleBean> msg = new ArrayList<MsgTitleBean>();
        msg = OpMessageTitle.queryTitle();
        // String m=msg.get(0).getTitleName();
        List<String> m = new ArrayList<String>();
        for (MsgTitleBean m1 : msg) {
            m.add(m1.getTitleName());
        }
        request.getSession().setAttribute("t_title", m);
        // System.out.println("fuck");
        // System.out.println(m);
        List<KlBean> klb = new ArrayList<KlBean>();
        klb = queryContact.queryAll();
        request.getSession().setAttribute("ss", klb);
        request.getRequestDispatcher("/index2.jsp").forward(request, response);
    }

}
