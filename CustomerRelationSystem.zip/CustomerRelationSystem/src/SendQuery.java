import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.care.bean.HyBean;
import com.care.bean.KlBean;
import com.care.bean.MsgTitleBean;
import com.care.dao.OpMessageTitle;
import com.care.dao.queryContact;
import com.care.dao.queryHeYueContact;

public class SendQuery extends HttpServlet {

    /**
     * The doGet method of the servlet. <br>
     * <p>
     * This method is called when a form has its tag value method equals to get.
     *
     * @param request  the request send by the client to the server
     * @param response the response send by the server to the client
     * @throws ServletException if an error occurred
     * @throws IOException      if an error occurred
     */
    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

    }

    /**
     * The doPost method of the servlet. <br>
     * <p>
     * This method is called when a form has its tag value method equals to
     * post.
     *
     * @param request  the request send by the client to the server
     * @param response the response send by the server to the client
     * @throws ServletException if an error occurred
     * @throws IOException      if an error occurred
     */
    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");

        String pname = request.getParameter("pname");
        String ppname = request.getParameter("ppname");
        String pbirth = request.getParameter("pbirth");
        String ppbirth = request.getParameter("ppbirth");
        String ptel = request.getParameter("ptel");
        String pptel = request.getParameter("pptel");
        String pcost = request.getParameter("pcost");
        String ppcost1 = request.getParameter("ppcost1");
        String ppcost2 = request.getParameter("ppcost2");
        List<KlBean> klb = new ArrayList<KlBean>();
        List<HyBean> hyb = new ArrayList<HyBean>();


        if (pname == null && pbirth == null && ptel == null && pcost == null) {
            klb = queryContact.queryAll();
            hyb = queryHeYueContact.queryAll();
            //klb = queryContact.queryPersonByName(ppname);

			/*List<String> id = new ArrayList<String>();
			List<String> name = new ArrayList<String>();
			List<String> sex = new ArrayList<String>();
			List<String> tel = new ArrayList<String>();
			List<String> birth = new ArrayList<String>();
			List<String> age = new ArrayList<String>();
			List<String> mail = new ArrayList<String>();
			List<String> cost = new ArrayList<String>();*/

			
				/*
				 * id.add(k.getId()+""); name.add(k.getName());
				 * sex.add(k.getSex()); tel.add(k.getTel());
				 * birth.add(k.getBirthday()); age.add(k.getAge()+"");
				 * mail.add(k.getMail()); cost.add(k.getCost()+"");
				 * request.setAttribute("pid", id);
				 * request.setAttribute("pname", name);
				 * request.setAttribute("psex", sex);
				 * request.setAttribute("ptel", tel);
				 * request.setAttribute("pbirth", birth);
				 * request.setAttribute("page", age);
				 * request.setAttribute("pmail", mail);
				 * request.setAttribute("pcost", cost);
				 */
            System.out.println("cao");
            System.out.println(klb.get(0).getName());
        } else {
            if (pname != null && ppname != null) {

                klb = queryContact.queryPersonByName(ppname);
                hyb = queryHeYueContact.queryHyByName(ppname);
                //klb = queryContact.queryPersonByName(ppname);

            }
            if (pbirth != null && ppbirth != null) {
                klb = queryContact.queryPersonBybirth(ppbirth);
                hyb = queryHeYueContact.queryHyBybirth(ppbirth);
            }
            if (ptel != null && pptel != null) {
                klb = queryContact.queryPersonByTel(pptel);
                hyb = queryHeYueContact.queryaHyByTel(pptel);
            }
            if (pcost != null && ppcost1 != null && ppcost2 != null) {
                klb = queryContact.queryPersonByCost(Double.parseDouble(ppcost1), Double.parseDouble(ppcost2));
                hyb = queryHeYueContact.queryHyByCost(Double.parseDouble(ppcost1), Double.parseDouble(ppcost2));
            }
        }
        request.setAttribute("ss", klb);
        request.setAttribute("zz", hyb);
        List<MsgTitleBean> msg = new ArrayList<MsgTitleBean>();
        msg = OpMessageTitle.queryTitle();
//	String m=msg.get(0).getTitleName();
        List<String> m = new ArrayList<String>();
        for (MsgTitleBean m1 : msg) {
            m.add(m1.getTitleName());
        }
        request.setAttribute("t_title", m);


        request.getRequestDispatcher("/index3.jsp").forward(request, response);
    }


}


