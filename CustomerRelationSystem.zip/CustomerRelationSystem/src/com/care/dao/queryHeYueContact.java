package com.care.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.care.bean.HyBean;


public class queryHeYueContact {

	public static void main(String[] args) {
		// TODO �Զ���ɵķ������
	}
	
	public static List<HyBean> queryAll() {
		List<HyBean> Hy = new ArrayList<HyBean>();
		DB db = new DB();
		Connection conn = db.getConn();
		queryAllInfo(Hy, conn);
		
		return Hy;
	}
	
	private static void queryAllInfo(List<HyBean>persons, Connection conn) {
		String sql = "select * from hy_info";
		//String sql = "select * from kl_info";
		Statement stmt = DB.createStmt(conn);
		ResultSet rs = DB.executeQuery(stmt, sql);
		try {
			while(rs.next()) {
				HyBean a = new HyBean();
				a.setId(rs.getInt("hy_id"));
				a.setName(rs.getString("hy_name"));
				a.setTel(rs.getString("hy_tel"));
				a.setDaibiao(rs.getString("hy_daibiao"));
				a.setMail(rs.getString("hy_mail"));
				a.setAddress(rs.getString("hy_address"));
				a.setBirthday(rs.getDate("hy_birth").toString());
				a.setCost(rs.getDouble("hy_cost"));
				persons.add(a);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DB.close(rs);
			DB.close(stmt);
		}
	}
	
	//query by name
		public static List<HyBean> queryHyByName(String _name) {
			List<HyBean> Hy = new ArrayList<HyBean>();
			DB db = new DB();
			Connection conn = db.getConn();
			queryByName(Hy, conn, _name);
			return Hy;
		}
		
		
		
		private static void queryByName(List<HyBean>persons, Connection conn, String _name) {
			String sql = "select * from hy_info where hy_name = '"+_name+"'";
			//String sql = "select * from kl_info";
			Statement stmt = DB.createStmt(conn);
			ResultSet rs = DB.executeQuery(stmt, sql);
			try {
				while(rs.next()) {
					HyBean a = new HyBean();
					a.setId(rs.getInt("hy_id"));
					a.setName(rs.getString("hy_name"));
					a.setTel(rs.getString("hy_tel"));
					a.setDaibiao(rs.getString("hy_daibiao"));
					a.setMail(rs.getString("hy_mail"));
					a.setAddress(rs.getString("hy_address"));
					a.setBirthday(rs.getDate("hy_birth").toString());
					a.setCost(rs.getDouble("hy_cost"));
					persons.add(a);
				}
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				DB.close(rs);
				DB.close(stmt);
			}
		}
		
		//query by cost
		public static List<HyBean> queryHyByCost(double lCost, double rCost) {
			List<HyBean> Hy = new ArrayList<HyBean>();
			DB db = new DB();
			Connection conn = db.getConn();
			queryByCost(Hy, conn, lCost, rCost);
			return Hy;
		}
		
		private static void queryByCost(List<HyBean>persons, Connection conn, double lCost, double rCost) {
			String sql = "select * from hy_info where hy_cost >= '"+lCost+"' and hy_cost <='"+rCost+"'";
			//String sql = "select * from kl_info";
			Statement stmt = DB.createStmt(conn);
			ResultSet rs = DB.executeQuery(stmt, sql);
			try {
				while(rs.next()) {
					HyBean a = new HyBean();
					a.setId(rs.getInt("hy_id"));
					a.setName(rs.getString("hy_name"));
					a.setTel(rs.getString("hy_tel"));
					a.setDaibiao(rs.getString("hy_daibiao"));
					a.setMail(rs.getString("hy_mail"));
					a.setAddress(rs.getString("hy_address"));
					a.setBirthday(rs.getDate("hy_birth").toString());
					a.setCost(rs.getDouble("hy_cost"));
					persons.add(a);
				}
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				DB.close(rs);
				DB.close(stmt);
			}
		}
		
		//query by tel
		public static List<HyBean> queryaHyByTel(String _Tel) {
			List<HyBean> Hy = new ArrayList<HyBean>();
			DB db = new DB();
			Connection conn = db.getConn();
			queryByTel(Hy, conn, _Tel);
			return Hy;
		}
		
		private static void queryByTel(List<HyBean>persons, Connection conn, String _Tel) {
			String sql = "select * from hy_info where hy_tel = '"+_Tel+"'";
			Statement stmt = DB.createStmt(conn);
			ResultSet rs = DB.executeQuery(stmt, sql);
			try {
				while(rs.next()) {
					HyBean a = new HyBean();
					a.setId(rs.getInt("hy_id"));
					a.setName(rs.getString("hy_name"));
					a.setTel(rs.getString("hy_tel"));
					a.setDaibiao(rs.getString("hy_daibiao"));
					a.setMail(rs.getString("hy_mail"));
					a.setAddress(rs.getString("hy_address"));
					a.setBirthday(rs.getDate("hy_birth").toString());
					a.setCost(rs.getDouble("hy_cost"));
					persons.add(a);
				}
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				DB.close(rs);
				DB.close(stmt);
			}
		}
		
		//query by birthday
			public static List<HyBean> queryHyBybirth(String _Date) {
				List<HyBean> Hy = new ArrayList<HyBean>();
				DB db = new DB();
				Connection conn = db.getConn();
				queryByBirthday(Hy, conn, _Date);
				return Hy;
			}
			
			private static void queryByBirthday(List<HyBean>persons, Connection conn, String _Date) {
				String sql = "select * from hy_info where hy_birth = '"+_Date+"'";
				Statement stmt = DB.createStmt(conn);
				ResultSet rs = DB.executeQuery(stmt, sql);
				try {
					while(rs.next()) {
						HyBean a = new HyBean();
						a.setId(rs.getInt("hy_id"));
						a.setName(rs.getString("hy_name"));
						a.setTel(rs.getString("hy_tel"));
						a.setDaibiao(rs.getString("hy_daibiao"));
						a.setMail(rs.getString("hy_mail"));
						a.setAddress(rs.getString("hy_address"));
						a.setBirthday(rs.getDate("hy_birth").toString());
						a.setCost(rs.getDouble("hy_cost"));
						persons.add(a);
					}
				} catch (SQLException e) {
					e.printStackTrace();
				} finally {
					DB.close(rs);
					DB.close(stmt);
				}
			}
			
			//query by daibiao
			
			public static List<HyBean> queryHyByDaibiao(String _name) {
				List<HyBean> Hy = new ArrayList<HyBean>();
				DB db = new DB();
				Connection conn = db.getConn();
				queryByDaibiao(Hy, conn, _name);
				return Hy;
			}
			
			
			
			private static void queryByDaibiao(List<HyBean>persons, Connection conn, String _name) {
				String sql = "select * from hy_info where hy_daibiao = '"+_name+"'";
				//String sql = "select * from kl_info";
				Statement stmt = DB.createStmt(conn);
				ResultSet rs = DB.executeQuery(stmt, sql);
				try {
					while(rs.next()) {
						HyBean a = new HyBean();
						a.setId(rs.getInt("hy_id"));
						a.setName(rs.getString("hy_name"));
						a.setTel(rs.getString("hy_tel"));
						a.setDaibiao(rs.getString("hy_daibiao"));
						a.setMail(rs.getString("hy_mail"));
						a.setAddress(rs.getString("hy_address"));
						a.setBirthday(rs.getDate("hy_birth").toString());
						a.setCost(rs.getDouble("hy_cost"));
						persons.add(a);
					}
				} catch (SQLException e) {
					e.printStackTrace();
				} finally {
					DB.close(rs);
					DB.close(stmt);
				}
			}
}
