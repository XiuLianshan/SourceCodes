package com.care.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.care.bean.HyBean;
import com.care.bean.MessageBean;
import com.care.bean.MsgBean;


public class InsertMessage {

	public static void main(String[] args) {
		// TODO �Զ���ɵķ������

	}
	
	
	// insert msgs
	public static int nowId() {
		int now = -1;
		List<MessageBean> Mb = new ArrayList<MessageBean>();
		DB db = new DB();
		Connection conn = db.getConn();
		queryMsg(Mb, conn);
		for(Iterator i = Mb.iterator(); i.hasNext();) {
			MessageBean a = (MessageBean) i.next();
			now = a.getId();
		}
		if(now == -1) return 1;
		now++;
		return now;
	}
	
	public static void insertMsg(List<MsgBean> msg, String _type) {
		for(Iterator i = msg.iterator(); i.hasNext();) {
			MsgBean mm = (MsgBean) i.next();
			MessageBean now = new MessageBean();
			now.setName(mm.getMsgReceiver());
			now.setContent(mm.getMsgContent());
			now.setTitle(mm.getMsgTitle());
			now.setTel(mm.getMsgTel());
			now.setId(nowId());
			now.setState("已发送");
			String nowTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(
	                new Date(System.currentTimeMillis())).toString();
			now.setTime(nowTime);
			String nowDate = new SimpleDateFormat("yyyy-MM-dd").format(
	                new Date(System.currentTimeMillis())).toString();
			now.setDate(nowDate);
			now.setType(_type);
			DB db = new DB();
			Connection conn = db.getConn();
			insertMsg(conn, now);
		}
	}
	
	
	public static void insertMsg(Connection con, MessageBean msg) {
        String sql = null;
        sql = "INSERT INTO msg_info(msg_id, msg_name, msg_tel, msg_title, msg_content, msg_time, msg_date, msg_state, msg_type) VALUES ('" + msg.getId()
                + "','" + msg.getName() + "','" + msg.getTel() + "','" + msg.getTitle() + "','" + msg.getContent() + "','" + msg.getTime() + "','" + msg.getDate() + "','" + msg.getState() + "','" + msg.getType() + "') ";
        try {
            con.createStatement().execute(sql);
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
	}
	
	
	// query by name
	
	public static List<MessageBean> queryMsgByName(String _name) {
		List<MessageBean> mb = new ArrayList<MessageBean>();
		DB db = new DB();
		Connection conn = db.getConn();
		queryByName(mb, conn, _name);
		return mb;
	}
	
	
	private static void queryByName(List<MessageBean> persons, Connection conn, String _name) {
		String sql = "select * from msg_info where msg_name = '"+ _name +"'";
		Statement stmt = DB.createStmt(conn);
		ResultSet rs = DB.executeQuery(stmt, sql);
		try {
			while(rs.next()) {
				MessageBean a = new MessageBean();
				a.setId(rs.getInt("msg_id"));
				a.setName(rs.getString("msg_name"));
				a.setTel(rs.getString("msg_tel"));
				a.setTitle(rs.getString("msg_title"));
				a.setContent(rs.getString("msg_content"));
				a.setTime(rs.getString("msg_time"));
				a.setDate(rs.getDate("msg_date").toString());
				a.setState(rs.getString("msg_state"));
				a.setType(rs.getString("msg_type"));
				persons.add(a);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DB.close(rs);
			DB.close(stmt);
		}
	}
	
	// query by title
	
		public static List<MessageBean> queryMsgByType(String _type) {
			List<MessageBean> mb = new ArrayList<MessageBean>();
			DB db = new DB();
			Connection conn = db.getConn();
			queryByType(mb, conn, _type);
			return mb;
		}
		
		
		private static void queryByType(List<MessageBean> persons, Connection conn, String _type) {
			String sql = "select * from msg_info where msg_type = '"+ _type +"'";
			Statement stmt = DB.createStmt(conn);
			ResultSet rs = DB.executeQuery(stmt, sql);
			try {
				while(rs.next()) {
					MessageBean a = new MessageBean();
					a.setId(rs.getInt("msg_id"));
					a.setName(rs.getString("msg_name"));
					a.setTel(rs.getString("msg_tel"));
					a.setTitle(rs.getString("msg_title"));
					a.setContent(rs.getString("msg_content"));
					a.setTime(rs.getString("msg_time"));
					a.setDate(rs.getDate("msg_date").toString());
					a.setState(rs.getString("msg_state"));
					a.setType(rs.getString("msg_type"));
					persons.add(a);
				}
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				DB.close(rs);
				DB.close(stmt);
			}
		}
	
	// query by title
	
	public static List<MessageBean> queryMsgByTitle(String _title) {
		List<MessageBean> mb = new ArrayList<MessageBean>();
		DB db = new DB();
		Connection conn = db.getConn();
		queryByTitle(mb, conn, _title);
		return mb;
	}
	public static List<MessageBean> queryAllInfo(){
		
		List<MessageBean> mb =new ArrayList<MessageBean>();
		DB db= new DB();
		Connection connection=db.getConn();
		queryMsg(mb, connection);
		return mb;
	}
	
	private static void queryByTitle(List<MessageBean> persons, Connection conn, String _title) {
		String sql = "select * from msg_info where msg_title = '"+ _title +"'";
		Statement stmt = DB.createStmt(conn);
		ResultSet rs = DB.executeQuery(stmt, sql);
		try {
			while(rs.next()) {
				MessageBean a = new MessageBean();
				a.setId(rs.getInt("msg_id"));
				a.setName(rs.getString("msg_name"));
				a.setTel(rs.getString("msg_tel"));
				a.setTitle(rs.getString("msg_title"));
				a.setContent(rs.getString("msg_content"));
				a.setTime(rs.getString("msg_time"));
				a.setDate(rs.getDate("msg_date").toString());
				a.setState(rs.getString("msg_state"));
				a.setType(rs.getString("msg_type"));
				persons.add(a);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DB.close(rs);
			DB.close(stmt);
		}
	}
	
	//query by hygs_name
	public static List<MessageBean> queryMsgByHyName(String _name) {
		List<MessageBean> mb = new ArrayList<MessageBean>();
		DB db = new DB();
		Connection conn = db.getConn();
		queryHeYueContact hy = new queryHeYueContact();
		List<HyBean> HB = hy.queryHyByName(_name);
		String _Dname = null;
		for(Iterator i = HB.iterator(); i.hasNext();) {
			HyBean temp = (HyBean) i.next();
			_Dname = temp.getDaibiao();
		}
		queryByHyName(mb, conn, _Dname);
		return mb;
	}
	
	
	private static void queryByHyName(List<MessageBean> persons, Connection conn, String _name) {
		final String type = "合约公司";
		String sql = "select * from msg_info where msg_name = '"+ _name +"' and msg_type = '"+type+"'";
		Statement stmt = DB.createStmt(conn);
		ResultSet rs = DB.executeQuery(stmt, sql);
		try {
			while(rs.next()) {
				MessageBean a = new MessageBean();
				a.setId(rs.getInt("msg_id"));
				a.setName(rs.getString("msg_name"));
				a.setTel(rs.getString("msg_tel"));
				a.setTitle(rs.getString("msg_title"));
				a.setContent(rs.getString("msg_content"));
				a.setTime(rs.getString("msg_time"));
				a.setDate(rs.getDate("msg_date").toString());
				a.setState(rs.getString("msg_state"));
				a.setType(rs.getString("msg_type"));
				persons.add(a);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DB.close(rs);
			DB.close(stmt);
		}
	}
	//query from sql
	
	private static void queryMsg(List<MessageBean> persons, Connection conn) {
		String sql = "select * from msg_info order by Msg_id";
		Statement stmt = DB.createStmt(conn);
		ResultSet rs = DB.executeQuery(stmt, sql);
		try {
			while(rs.next()) {
				MessageBean a = new MessageBean();
				a.setId(rs.getInt("msg_id"));
				a.setName(rs.getString("msg_name"));
				a.setTel(rs.getString("msg_tel"));
				a.setTitle(rs.getString("msg_title"));
				a.setContent(rs.getString("msg_content"));
				a.setTime(rs.getString("msg_time"));
				a.setDate(rs.getDate("msg_date").toString());
				a.setState(rs.getString("msg_state"));
				a.setType(rs.getString("msg_type"));
				persons.add(a);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DB.close(rs);
			DB.close(stmt);
		}
	}
}
