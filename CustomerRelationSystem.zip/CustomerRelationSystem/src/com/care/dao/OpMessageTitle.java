package com.care.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.care.bean.MsgTitleBean;


public class OpMessageTitle {
	public static void main(String[] args) {
		// TODO �Զ���ɵķ������
		//addMsgTitle("ʥ��ף��");
		//deleteMsgTitle("ʥ��ף��");
	}
	
	//query msg titles
	
	public static List<MsgTitleBean> queryTitle() {
		List<MsgTitleBean> MT = new ArrayList<MsgTitleBean>();
		DB db = new DB();
		Connection conn = db.getConn();
		queryMsgTitle(MT, conn);
		return MT;
	}
	
	//add a msg title
	
	public static int findMinId() {
		List<MsgTitleBean> MT = queryTitle();
		int now = -1;
		MsgTitleBean temp = new MsgTitleBean();
		for(Iterator i = MT.iterator(); i.hasNext();) {
			temp = (MsgTitleBean) i.next();
			if(now == -1) {
				if(temp.getId() == 1) {
					now = 1;
				}
				else {
					now = 0;
					break;
				}
			}
			else {
				int nowId = temp.getId();
				if(nowId - now == 1) {
					now = nowId;
				}
				else {
					break;
				}
			}
		}
		now++;
		//System.out.println(now);
		return now;
	}
	
	public static void addMsgTitle(String _name) {
		queryTitle();
		int _id = findMinId();
		DB db = new DB();
		Connection conn = db.getConn();
		addTitle(conn, _id, _name);
	}
	
	public static void addTitle(Connection con, int _id, String _name) {
        String sql = null;
        sql = "INSERT INTO msg_title(Msg_id, Msg_name) VALUES ('" + _id
                + "','" + _name + "') ";
        try {
            con.createStatement().execute(sql);
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
	}
	
	//delete msg title
	
	
	public static void deleteMsgTitle(String _name) {
		DB db = new DB();
		Connection conn = db.getConn();
		deleteTitle(conn, _name);
	}
	
	
	public static void deleteTitle(Connection con, String _name) {
        String sql = null;
        sql = "delete from msg_title where Msg_name = '"+_name+"'";
        try {
            con.createStatement().execute(sql);
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
	}
	
	
	
	private static void queryMsgTitle(List<MsgTitleBean> persons, Connection conn) {
		String sql = "select * from msg_title order by Msg_id";
		Statement stmt = DB.createStmt(conn);
		ResultSet rs = DB.executeQuery(stmt, sql);
		try {
			while(rs.next()) {
				MsgTitleBean a = new MsgTitleBean();
				a.setId(rs.getInt("Msg_id"));
				a.setTitleName(rs.getString("Msg_name"));
				persons.add(a);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DB.close(rs);
			DB.close(stmt);
		}
	}
}
