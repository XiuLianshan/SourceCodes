package com.care.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.care.bean.KlBean;


public class queryContact {
	public static void main(String[] args) {
		
	}
	
	//query
	
	public static List<KlBean> queryAll() {
		List<KlBean> Kl = new ArrayList<KlBean>();
		DB db = new DB();
		Connection conn = db.getConn();
		queryAllInfo(Kl, conn);
		
		return Kl;
	}
	
	private static void queryAllInfo(List<KlBean>persons, Connection conn) {
		String sql = "select * from kl_info";
		//String sql = "select * from kl_info";
		Statement stmt = DB.createStmt(conn);
		ResultSet rs = DB.executeQuery(stmt, sql);
		try {
			while(rs.next()) {
				KlBean a = new KlBean();
				a.setId(rs.getInt("kl_id"));
				a.setName(rs.getString("kl_name"));
				a.setTel(rs.getString("kl_tel"));
				a.setSex(rs.getString("kl_sex"));
				a.setAge(rs.getInt("kl_age"));
				a.setMail(rs.getString("kl_mail"));
				a.setAddress(rs.getString("kl_address"));
				a.setBirthday(rs.getDate("kl_birth").toString());
				a.setCost(rs.getDouble("kl_cost"));
				persons.add(a);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DB.close(rs);
			DB.close(stmt);
		}
	}
	
	//query by name
	public static List<KlBean> queryPersonByName(String _name) {
		List<KlBean> Kl = new ArrayList<KlBean>();
		DB db = new DB();
		Connection conn = db.getConn();
		queryByName(Kl, conn, _name);
		return Kl;
	}
	
	
	
	private static void queryByName(List<KlBean>persons, Connection conn, String _name) {
		String sql = "select * from kl_info where kl_name = '"+_name+"'";
		//String sql = "select * from kl_info";
		Statement stmt = DB.createStmt(conn);
		ResultSet rs = DB.executeQuery(stmt, sql);
		try {
			while(rs.next()) {
				KlBean a = new KlBean();
				a.setId(rs.getInt("kl_id"));
				a.setName(rs.getString("kl_name"));
				a.setTel(rs.getString("kl_tel"));
				a.setSex(rs.getString("kl_sex"));
				a.setAge(rs.getInt("kl_age"));
				a.setMail(rs.getString("kl_mail"));
				a.setAddress(rs.getString("kl_address"));
				a.setBirthday(rs.getDate("kl_birth").toString());
				a.setCost(rs.getDouble("kl_cost"));
				persons.add(a);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DB.close(rs);
			DB.close(stmt);
		}
	}
	
	//query by cost
	public static List<KlBean> queryPersonByCost(double lCost, double rCost) {
		List<KlBean> Kl = new ArrayList<KlBean>();
		DB db = new DB();
		Connection conn = db.getConn();
		queryByCost(Kl, conn, lCost, rCost);
		return Kl;
	}
	
	private static void queryByCost(List<KlBean>persons, Connection conn, double lCost, double rCost) {
		String sql = "select * from kl_info where kl_cost >= '"+lCost+"' and kl_cost <='"+rCost+"'";
		//String sql = "select * from kl_info";
		Statement stmt = DB.createStmt(conn);
		ResultSet rs = DB.executeQuery(stmt, sql);
		try {
			while(rs.next()) {
				KlBean a = new KlBean();
				a.setId(rs.getInt("kl_id"));
				a.setName(rs.getString("kl_name"));
				a.setTel(rs.getString("kl_tel"));
				a.setSex(rs.getString("kl_sex"));
				a.setAge(rs.getInt("kl_age"));
				a.setMail(rs.getString("kl_mail"));
				a.setAddress(rs.getString("kl_address"));
				a.setBirthday(rs.getDate("kl_birth").toString());
				a.setCost(rs.getDouble("kl_cost"));
				persons.add(a);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DB.close(rs);
			DB.close(stmt);
		}
	}
	
	//query by tel
	public static List<KlBean> queryPersonByTel(String _Tel) {
		List<KlBean> Kl = new ArrayList<KlBean>();
		DB db = new DB();
		Connection conn = db.getConn();
		queryByTel(Kl, conn, _Tel);
		return Kl;
	}
	
	private static void queryByTel(List<KlBean>persons, Connection conn, String _Tel) {
		String sql = "select * from kl_info where kl_tel = '"+_Tel+"'";
		Statement stmt = DB.createStmt(conn);
		ResultSet rs = DB.executeQuery(stmt, sql);
		try {
			while(rs.next()) {
				KlBean a = new KlBean();
				a.setId(rs.getInt("kl_id"));
				a.setName(rs.getString("kl_name"));
				a.setTel(rs.getString("kl_tel"));
				a.setSex(rs.getString("kl_sex"));
				a.setAge(rs.getInt("kl_age"));
				a.setMail(rs.getString("kl_mail"));
				a.setAddress(rs.getString("kl_address"));
				a.setBirthday(rs.getDate("kl_birth").toString());
				a.setCost(rs.getDouble("kl_cost"));
				persons.add(a);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DB.close(rs);
			DB.close(stmt);
		}
	}
	
	//query by birthday
		public static List<KlBean> queryPersonBybirth(String _Date) {
			List<KlBean> Kl = new ArrayList<KlBean>();
			DB db = new DB();
			Connection conn = db.getConn();
			queryByBirthday(Kl, conn, _Date);
			return Kl;
		}
		
		private static void queryByBirthday(List<KlBean>persons, Connection conn, String _Date) {
			String sql = "select * from kl_info where kl_birth = '"+_Date+"'";
			Statement stmt = DB.createStmt(conn);
			ResultSet rs = DB.executeQuery(stmt, sql);
			try {
				while(rs.next()) {
					KlBean a = new KlBean();
					a.setId(rs.getInt("kl_id"));
					a.setName(rs.getString("kl_name"));
					a.setTel(rs.getString("kl_tel"));
					a.setSex(rs.getString("kl_sex"));
					a.setAge(rs.getInt("kl_age"));
					a.setMail(rs.getString("kl_mail"));
					a.setAddress(rs.getString("kl_address"));
					a.setBirthday(rs.getDate("kl_birth").toString());
					a.setCost(rs.getDouble("kl_cost"));
					persons.add(a);
				}
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				DB.close(rs);
				DB.close(stmt);
			}
		}
}
