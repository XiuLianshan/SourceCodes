package com.care.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.care.bean.PersonBean;

public class DataGet {
	

	public List<PersonBean> getPersons() {
		Connection conn = ConnectDatabase.getConn();
		List<PersonBean> persons =new ArrayList<PersonBean>();
		String sql = "select * from userinfo";
		PreparedStatement stmt = null;
		ResultSet rs = null;

		try {
			stmt = conn.prepareStatement(sql);
			rs = stmt.executeQuery();
			while (rs.next()) {
				PersonBean pb=new PersonBean();
				pb.setId(rs.getInt(1));
				//System.out.println(rs.getInt(1));
				pb.setName(rs.getString(2));
				pb.setNameJP(rs.getString(3));
				pb.setSex(rs.getString(4));
				pb.setTel(rs.getString(5));
				persons.add(pb);
				//System.out.println(persons.get(0));
			}

		} catch (SQLException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
		finally{
			DBUtils.closeConnection(conn);
			DBUtils.closePreparedStatement(stmt);
			DBUtils.closeResultSet(rs);
		}
		return persons;

	}
}