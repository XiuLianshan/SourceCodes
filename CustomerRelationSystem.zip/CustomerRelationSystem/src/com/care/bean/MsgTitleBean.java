package com.care.bean;

public class MsgTitleBean {
	int id;
	String titleName;
	public static void main(String[] args) {
		// TODO �Զ���ɵķ������

	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTitleName() {
		return titleName;
	}
	public void setTitleName(String titleName) {
		this.titleName = titleName;
	}
	
}
