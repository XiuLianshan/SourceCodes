package com.care.bean;

public class PersonBean {//封装数据的personbean
	private int id;
	private String name;
	private String nameJP;
	private String sex;
	private String tel;
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	  
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getNameJP() {
		return nameJP;
	}

	public void setNameJP(String nameJP) {
		this.nameJP = nameJP;
	}

	public String getTel() {
		return tel;
	}

	public void setTel(String tel) {
		this.tel = tel;
	}

	public String getSex() {
		return sex;
	}
	

	
	@Override
	public String toString() {
		return id + ", " + name + ", " + sex + "," + tel
				;
	}

	public PersonBean() {
		
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	

	

}
