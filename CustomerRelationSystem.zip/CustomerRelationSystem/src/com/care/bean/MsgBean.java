package com.care.bean;

public class MsgBean {
	String msgTitle;
	String msgContent;
	String msgReceiver;
	String msgTel;
	public static void main(String[] args) {
		// TODO �Զ���ɵķ������

	}
	public String getMsgTitle() {
		return msgTitle;
	}
	public void setMsgTitle(String msgTitle) {
		this.msgTitle = msgTitle;
	}
	public String getMsgContent() {
		return msgContent;
	}
	public void setMsgContent(String msgContent) {
		this.msgContent = msgContent;
	}
	public String getMsgReceiver() {
		return msgReceiver;
	}
	public void setMsgReceiver(String msgReceiver) {
		this.msgReceiver = msgReceiver;
	}
	public String getMsgTel() {
		return msgTel;
	}
	public void setMsgTel(String msgTel) {
		this.msgTel = msgTel;
	}
	
}
