package com.mybatis.servlet;

import com.mybatis.mapper.NoteMapper;
import com.mybatis.mapper.PageMapper;
import com.mybatis.po.Note;
import com.mybatis.po.NumberSB;
import com.mybatis.po.PageBean;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

/**
 * Created by XiuLianshan on 2015/12/24.
 */
@WebServlet(name = "MBServlet")
public class MBServlet extends HttpServlet {
    private SqlSessionFactory sqlSessionFactory;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);


    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        //import mybatis configuration file
        String resource = "config/SqlMapConfig.xml";
        //get the configuration file as a stream
        InputStream inputStream = Resources.getResourceAsStream(resource);
        //create a sqlsessionfactory with the configuration information
        sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
        //get the sqlsession by factory
        SqlSession sqlSession = sqlSessionFactory.openSession();

        //    NoteMapper noteMapper = sqlSession.getMapper(NoteMapper.class);
        //   request.getRequestDispatcher("/J2EE/MessageBoard.jsp").forward(request,response);

        String nowp = request.getParameter("pageCode");

        System.out.println("asadsasd" + nowp);
        PageMapper pageMapper = sqlSession.getMapper(PageMapper.class);
        int total = (int) pageMapper.queryAll();
        int pageCode;
        int pageSize = 5;

        int lastPage = total / pageSize + 1;

        if (nowp == null || nowp.trim().isEmpty()) {
            pageCode = 1;
        } else {
            pageCode = Integer.parseInt(nowp);
            if(pageCode<=1)
            {
                pageCode=1;
            }
            if (pageCode>=lastPage)
            {
                pageCode=lastPage;
            }
        }

       // System.out.println("big sb" + total);

        NumberSB numberSB = new NumberSB();
        numberSB.setA((pageCode - 1) * pageSize);
        numberSB.setB(pageSize);
        List<Note> noteList = pageMapper.queryPart(numberSB);


        request.getSession().setAttribute("lastPage", lastPage);
        request.getSession().setAttribute("noteList", noteList);
        request.getSession().setAttribute("pageCode", pageCode);

        sqlSession.close();


        response.sendRedirect("/J2EE/MessageBoard.jsp");
        /*try {
            List<Note> noteLists = noteMapper.findNotes();
            System.out.println(noteLists);

            System.out.println("hey");

            request.getSession().setAttribute("noteList", noteLists);






           */
         /* PageMapper pageMapper=sqlSession.getMapper(PageMapper.class);

            int pageCode = getPageCode(request);
            System.out.println("this is pageCode"+pageCode);
            int pageSize = 5;
            Number number = pageMapper.queryAll();
            int totalRecord = number.intValue();

            List<Note> noteList = pageMapper.queryPart((pageCode-1)*pageSize,pageSize);
            PageBean<Note> pageBean= new PageBean<Note>();
            pageBean.setPageSize(pageSize);
            pageBean.setPageCode(pageCode);
            pageBean.setTotalRecord(totalRecord);
            pageBean.setBeanList(noteList);

            request.setAttribute("pageBean",pageBean);*//*
            sqlSession.close();


            response.sendRedirect("/J2EE/MessageBoard.jsp");
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        }
*/
        //sqlSession.close();


    }

   /* private int getPageCode(HttpServletRequest request) {
        String value = request.getParameter("pageCode");
        if (value == null || value.trim().equals("")) {
            return 1;
        }
        return Integer.parseInt(value);
    }
*/

}
