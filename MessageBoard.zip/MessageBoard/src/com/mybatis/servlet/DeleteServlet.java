package com.mybatis.servlet;

import com.mybatis.mapper.NoteMapper;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.InputStream;

/**
 * Created by XiuLianshan on 2015/12/24.
 */
@WebServlet(name = "DeleteServlet")
public class DeleteServlet extends HttpServlet {
    private SqlSessionFactory sqlSessionFactory;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // request.getContextPath();
        // System.out.println("fuck");
        // response.getWriter().write("fuck");
        String resource = "config/SqlMapConfig.xml";
        //get the configuration file as a stream
        InputStream inputStream = Resources.getResourceAsStream(resource);
        //create a sqlsessionfactory with the configuration information
        sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
        //get the sqlsession by factory
        SqlSession sqlSession = sqlSessionFactory.openSession();

        NoteMapper noteMapper = sqlSession.getMapper(NoteMapper.class);
        String nid = request.getParameter("id");
        int id = Integer.parseInt(nid);

        try {
            noteMapper.deleteNote(id);
            sqlSession.commit();
            sqlSession.close();
            response.sendRedirect("/J2EE/MBServlet?pageCode=1");
            // request.getRequestDispatcher("/MBServlet").forward(request,response);

        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
