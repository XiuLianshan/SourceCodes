package com.mybatis.servlet;

import com.mybatis.mapper.NoteMapper;
import com.mybatis.po.Note;
import com.mybatis.po.Person;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.InputStream;

/**
 * Created by XiuLianshan on 2015/12/24.
 */
@WebServlet(name = "InsertServlet")
public class InsertServlet extends HttpServlet {
    private SqlSessionFactory sqlSessionFactory;
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // request.getContextPath();
       // System.out.println("fuck");
        // response.getWriter().write("fuck");
        String resource = "config/SqlMapConfig.xml";
        //get the configuration file as a stream
        InputStream inputStream = Resources.getResourceAsStream(resource);
        //create a sqlsessionfactory with the configuration information
        sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
        //get the sqlsession by factory
        SqlSession sqlSession = sqlSessionFactory.openSession();

        NoteMapper noteMapper = sqlSession.getMapper(NoteMapper.class);

        Note note = new Note();
        String title = request.getParameter("title");
        String content = request.getParameter("content");
        Person person = (Person) request.getSession().getAttribute("Person");
        System.out.println( title);
        System.out.println( content);
        System.out.println( person.getName());
        note.setTitle(title);
        note.setAuthor(person.getName());
        note.setContent(content);

        try {
            noteMapper.insertNote(note);
            request.getRequestDispatcher("/MBServlet").forward(request,response);
            sqlSession.commit();
            sqlSession.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
