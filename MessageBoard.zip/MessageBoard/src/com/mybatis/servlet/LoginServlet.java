package com.mybatis.servlet;

import com.mybatis.mapper.PersonMapper;
import com.mybatis.po.Person;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

/**
 * Created by XiuLianshan on 2015/12/23.
 */
@WebServlet(name = "LoginServlet")
public class LoginServlet extends HttpServlet {
    private SqlSessionFactory sqlSessionFactory;


    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
       /* response.sendRedirect("/WEB-INF/messageboard.jsp");
        response.getWriter().write("fuck");*/
        //  System.out.println("fuck");
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // request.getContextPath();
        System.out.println("fuck");
        // response.getWriter().write("fuck");
        String resource = "config/SqlMapConfig.xml";
        //get the configuration file as a stream
        InputStream inputStream = Resources.getResourceAsStream(resource);
        //create a sqlsessionfactory with the configuration information
        sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
        //get the sqlsession by factory
        SqlSession sqlSession = sqlSessionFactory.openSession();

        PersonMapper personMapper = sqlSession.getMapper(PersonMapper.class);


        try {
            List<Person> personList = personMapper.findPersons();
            System.out.println(personList);

            String username, password;
            username = request.getParameter("username");
            password = request.getParameter("password");
            System.out.println(username + password);
            int pp = 0;
            for (Person p : personList) {

                if (p.getName().equals(username) && p.getPassword().equals(password)) {
                    //System.out.println("fuck");
                    request.getSession().setAttribute("Person",p);
                    //response.sendRedirect("/MBServlet");
                    // request.getRequestDispatcher("/MBServlet").forward(request, response);
                    pp = 2;
                } else {
                    System.out.println("shit");
                    //无此用户跳转到其他页面
                    // response.sendRedirect("/Wrong.jsp");
                    //  request.getRequestDispatcher("/Wrong.jsp").forward(request, response);
                    pp = 1;
                }

            }
            if (pp == 1) {
                response.sendRedirect("/Wrong.jsp");
            }
            if (pp == 2) {
                response.sendRedirect("/J2EE/MessageBoard.jsp");
            }


            // request.getSession().setAttribute("personList",personList);

            // request.getRequestDispatcher("/MBServlet").forward(request, response);
            // request.getParameter("");
            sqlSession.close();
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        }
    }
}
