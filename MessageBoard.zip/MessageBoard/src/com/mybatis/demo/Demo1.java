package com.mybatis.demo;

import com.mybatis.po.User;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.Test;


import java.io.IOException;
import java.io.InputStream;
import java.util.List;

/**
 * Created by XiuLianshan on 2015/12/13.
 */
public class Demo1 {
    @Test
    public void findUserById() throws IOException {
        //import mybatis configuration file
        String resource = "config/SqlMapConfig.xml";
        //get the configuration file as a stream
        InputStream inputStream = Resources.getResourceAsStream(resource);
        //create a sqlsessionfactory with the configuration information
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
        //get the sqlsession by factory
        SqlSession sqlSession = sqlSessionFactory.openSession();

        //now get the database with sqlsession
        System.out.println("fuck");
        // User user = sqlSession.selectOne("test.findUserById", 1);
        User user = sqlSession.selectOne("test.findUserById", 1);
        //没有引入mysql的驱动包 然后检查检查文件路径都是否正确。
        System.out.println(user);

        sqlSession.close();
    }

    @Test
    public void findUserByName() throws IOException {
        //import mybatis configuration file
        String resource = "config/SqlMapConfig.xml";
        //get the configuration file as a stream
        InputStream inputStream = Resources.getResourceAsStream(resource);
        //create a sqlsessionfactory with the configuration information
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
        //get the sqlsession by factory
        SqlSession sqlSession = sqlSessionFactory.openSession();
        List<User> userList = sqlSession.selectList("test.findUserByName", "快");
        System.out.println(userList.toString());
        sqlSession.close();

    }

    @Test
    public void insertUser() throws IOException {
        //import mybatis configuration file
        String resource = "config/SqlMapConfig.xml";
        //get the configuration file as a stream
        InputStream inputStream = Resources.getResourceAsStream(resource);
        //create a sqlsessionfactory with the configuration information
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
        //get the sqlsession by factory
        SqlSession sqlSession = sqlSessionFactory.openSession();

        User user = new User();
        user.setId(30);
        user.setAge(22);
        user.setName("张三");
        sqlSession.insert("test.insertUser", user);
        sqlSession.commit();
        sqlSession.close();
    }
    @Test
    public void deleteUser() throws IOException {
        //import mybatis configuration file
        String resource = "config/SqlMapConfig.xml";
        //get the configuration file as a stream
        InputStream inputStream = Resources.getResourceAsStream(resource);
        //create a sqlsessionfactory with the configuration information
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
        //get the sqlsession by factory
        SqlSession sqlSession = sqlSessionFactory.openSession();
        sqlSession.delete("test.deleteUser",1);
        sqlSession.commit();
        sqlSession.close();
    }
    @Test
    public void updateUser() throws IOException {
        //import mybatis configuration file
        String resource = "config/SqlMapConfig.xml";
        //get the configuration file as a stream
        InputStream inputStream = Resources.getResourceAsStream(resource);
        //create a sqlsessionfactory with the configuration information
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
        //get the sqlsession by factory
        SqlSession sqlSession = sqlSessionFactory.openSession();

        User user = new User();
        user.setId(30);
        user.setAge(10);
        user.setName("李四");
        sqlSession.insert("test.updateUser", user);
        sqlSession.commit();
        sqlSession.close();
    }
}
