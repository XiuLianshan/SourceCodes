package com.mybatis.demo;

import com.mybatis.mapper.NoteMapper;
import com.mybatis.mapper.PersonMapper;
import com.mybatis.mapper.UserMapper;
import com.mybatis.po.Note;
import com.mybatis.po.Person;
import com.mybatis.po.User;
import com.mybatis.po.UserQueryVo;
import org.apache.ibatis.io.Resources;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

/**
 * Created by XiuLianshan on 2015/12/15.
 */
public class Demo2 {
    private SqlSessionFactory sqlSessionFactory;

    @Before
    public void set() throws IOException {
        //import mybatis configuration file
        String resource = "config/SqlMapConfig.xml";
        //get the configuration file as a stream
        InputStream inputStream = Resources.getResourceAsStream(resource);
        //create a sqlsessionfactory with the configuration information
        sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
        //get the sqlsession by factory
    }

    @Test
    public void fun() throws Exception {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        //创建usermapper对象  mybatis自动生成 代理对象
        UserMapper userMapper = sqlSession.getMapper(UserMapper.class);

        User user = userMapper.findUserById(5);

        System.out.println(user);


    }
    @Test
    public void fun3() throws Exception {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        //创建usermapper对象  mybatis自动生成 代理对象
        PersonMapper personMapper = sqlSession.getMapper(PersonMapper.class);

        List<Person> personList = personMapper.findPersons();

        System.out.println(personList.toString());
        /* UserMapper userMapper = sqlSession.getMapper(UserMapper.class);

        User user = userMapper.findUserById(5);

        System.out.println(user);*/
sqlSession.close();

    }
    @Test
    public void fun4() throws Exception {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        //创建usermapper对象  mybatis自动生成 代理对象
        NoteMapper noteMapper =sqlSession.getMapper(NoteMapper.class);

        List<Note> noteList = noteMapper.findNotes();

        System.out.println(noteList.toString());



        /* UserMapper userMapper = sqlSession.getMapper(UserMapper.class);

        User user = userMapper.findUserById(5);

        System.out.println(user);*/


    }
    @Test
    public void fun1() throws Exception {
        UserQueryVo userQueryVo = new UserQueryVo();
        User user = new User();
        user.setName("hiu");
        user.setAge(20);
        userQueryVo.setUser(user);

        SqlSession sqlSession = sqlSessionFactory.openSession();
            //创建usermapper对象  mybatis自动生成 代理对象
            UserMapper userMapper = sqlSession.getMapper(UserMapper.class);

            List<User> list = userMapper.findUserList(userQueryVo);
       // System.out.println(userQueryVo.getUser().getName());
        System.out.println(list);
    }
}
