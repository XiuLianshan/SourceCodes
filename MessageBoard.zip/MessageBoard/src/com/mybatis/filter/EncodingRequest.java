package com.mybatis.filter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import java.io.UnsupportedEncodingException;

/**
 * Created by XiuLianshan on 2015/12/24.
 */
public class EncodingRequest extends HttpServletRequestWrapper {
    private HttpServletRequest req;

    public EncodingRequest(HttpServletRequest request) {
        super(request);
        this.req = request;
    }

    public String getParameter(String name) {
        String value = req.getParameter(name);
        System.out.println("这是23行的空指针"+value);
        // 处理编码问题
        try {
            value = new String(value.getBytes("iso-8859-1"), "utf-8");
         //   System.out.println("这是23行的空指针"+value);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        return value;
    }
}