package com.mybatis.po;

/**
 * 包装类型
 * Created by XiuLianshan on 2015/12/15.
 */
public class UserQueryVo {
    private User user;

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }
}
