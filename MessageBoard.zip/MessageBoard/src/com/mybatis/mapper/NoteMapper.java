package com.mybatis.mapper;

import com.mybatis.po.Note;

import java.security.spec.ECField;
import java.util.List;

/**
 * Created by XiuLianshan on 2015/12/23.
 */
public interface NoteMapper {
    List<Note> findNotes() throws  Exception;

   // List<Note> findNotesByAuthor(String author) throws Exception;

    void insertNote(Note note) throws Exception;

    void deleteNote(int nid) throws  Exception;

   // void updateNote (Note note) throws Exception;


 }
