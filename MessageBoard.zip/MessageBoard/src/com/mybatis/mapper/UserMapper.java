package com.mybatis.mapper;

import com.mybatis.po.User;
import com.mybatis.po.UserQueryVo;

import java.util.List;

/**
 * Created by XiuLianshan on 2015/12/15.
 */
public interface UserMapper {
    List<User> findUserList(UserQueryVo userQueryVo) throws  Exception;

    User findUserById(int id) throws Exception;

    void insertUser(User user) throws Exception;

    void deleteUser(int id) throws Exception;

    List<User> findUserByName(String name) throws Exception;
}
