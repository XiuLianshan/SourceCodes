package com.mybatis.mapper;

import com.mybatis.po.Person;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by XiuLianshan on 2015/12/23.
 */
public interface PersonMapper {
    List<Person>  findPersons() throws Exception;
}
