package com.mybatis.mapper;

import com.mybatis.po.Note;
import com.mybatis.po.NumberSB;

import java.util.List;

/**
 * Created by XiuLianshan on 2015/12/24.
 */
public interface PageMapper {
    long queryAll();
    List<Note> queryPart(NumberSB numberSB);
}
