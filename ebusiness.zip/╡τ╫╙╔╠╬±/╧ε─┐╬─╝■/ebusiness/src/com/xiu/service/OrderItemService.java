package com.xiu.service;

import com.heu.domain.OrderItem;
import com.heu.service.Service;

public interface OrderItemService extends Service{
		void makeOrderItem(OrderItem orderItem);
		
		OrderItem getOrderItem(int order_id,int goods_id);
}
