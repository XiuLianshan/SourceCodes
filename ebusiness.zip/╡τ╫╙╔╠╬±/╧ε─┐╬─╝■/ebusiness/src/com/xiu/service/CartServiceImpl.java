package com.xiu.service;

import java.util.List;

import com.heu.domain.Cart;
import com.heu.domain.Goods;
import com.heu.factory.BasicFactory;
import com.xiu.dao.CartDao;

public class CartServiceImpl implements CartService {
	private CartDao cartdao = BasicFactory.getFactory().getDao(CartDao.class);

	@Override
	public void addGoodsToCart(Cart cart) {

		cartdao.addCart(cart);

	}

	@Override
	public void addGoods(Goods goods) {
		cartdao.addGoods(goods);

	}

	@Override
	public void deleteGoods(Goods goods) {
		cartdao.deleteGoods(goods);

	}

	@Override
	public List<Goods> getGoodsInCart(int user_id) {
		return cartdao.queryGoods(user_id);
	}

	@Override
	public void deleteGoodsFromCart(Cart cart) {
		cartdao.deleteGoodsFromCart(cart);

	}

	@Override
	public void updateGoodsNumber(Cart cart) {
		cartdao.updateGoodsNumber(cart);

	}

	@Override
	public void deleteCart(int user_id) {
		cartdao.deleteCart(user_id);

	}

	@Override
	public int getNumber(Cart cart) {
		return cartdao.getNumber(cart);
	}

}
