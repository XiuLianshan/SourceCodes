package com.xiu.service;

import com.heu.domain.Order;
import com.heu.factory.BasicFactory;
import com.xiu.dao.MailInfoDao;


public class MailInfoServiceImpl  implements MailInfoService{
	private MailInfoDao metal = BasicFactory.getFactory().getDao(MailInfoDao.class);
	 
	@Override
	public void addMainInfo(Order order) {
	
	
		metal.updateOrderMail(order);
		
	}

}
