package com.xiu.service;

import com.heu.domain.OrderItem;
import com.heu.factory.BasicFactory;
import com.xiu.dao.OrderItemDao;

public class OrderItemServiceImpl implements OrderItemService {
	private OrderItemDao orderItemDao = BasicFactory.getFactory().getDao(
			OrderItemDao.class);

	@Override
	public void makeOrderItem(OrderItem orderItem) {
		// TODO Auto-generated method stub
		orderItemDao.insertOrderItem(orderItem);
	}

	@Override
	public OrderItem getOrderItem(int order_id, int goods_id) {
	
		return orderItemDao.getOrderItem(order_id, goods_id);

	}

}
