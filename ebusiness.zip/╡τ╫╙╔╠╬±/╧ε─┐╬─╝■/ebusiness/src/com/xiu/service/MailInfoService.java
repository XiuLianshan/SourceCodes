package com.xiu.service;

import com.heu.domain.Order;
import com.heu.service.Service;

public interface MailInfoService  extends Service{
		void addMainInfo(Order order);
}
