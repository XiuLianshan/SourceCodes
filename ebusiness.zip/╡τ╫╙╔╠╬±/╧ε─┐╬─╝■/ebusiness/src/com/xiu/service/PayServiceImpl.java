package com.xiu.service;

import com.heu.domain.Order;
import com.heu.factory.BasicFactory;
import com.xiu.dao.PayDao;

public class PayServiceImpl implements PayService {
		private PayDao  payDao = BasicFactory.getFactory().getDao(PayDao.class);
	@Override
	public void makePayMethod(Order order) {
		// TODO Auto-generated method stub 
	      
		    order.setPay_method("");
			payDao.updatePayMethod(order);
	}
				
}
