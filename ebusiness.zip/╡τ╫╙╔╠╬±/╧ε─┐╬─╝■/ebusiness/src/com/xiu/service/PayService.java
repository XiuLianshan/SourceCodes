package com.xiu.service;

import com.heu.domain.Order;

public interface PayService {
		void makePayMethod(Order order);
}
