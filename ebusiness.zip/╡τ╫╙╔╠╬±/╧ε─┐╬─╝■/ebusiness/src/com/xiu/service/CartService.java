package com.xiu.service;

import java.util.List;

import com.heu.domain.Cart;
import com.heu.domain.Goods;
import com.heu.service.Service;

public interface CartService extends Service {
	void addGoodsToCart(Cart cart);

	void addGoods(Goods goods);

	void deleteGoods(Goods goods);

	List<Goods> getGoodsInCart( int user_id);

	void deleteGoodsFromCart(Cart cart);

	void updateGoodsNumber(Cart cart);

	void deleteCart(int user_id);
	
	int getNumber(Cart cart);

}
