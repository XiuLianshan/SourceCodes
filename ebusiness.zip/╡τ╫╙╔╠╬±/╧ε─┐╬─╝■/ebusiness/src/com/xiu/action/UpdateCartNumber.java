package com.xiu.action;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.heu.domain.Cart;
import com.heu.domain.User;
import com.heu.factory.BasicFactory;
import com.xiu.service.CartService;

public class UpdateCartNumber extends HttpServlet {

	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		//	String number=request.getParameter("goods_number");
			String id = request.getParameter("goods_id");
			String number = request.getParameter("goods_number");
			CartService cartService  =BasicFactory.getFactory().getService(CartService.class);
			/*User user = (User) request.getSession().getAttribute("user");
			if (user==null) {
				return;
			}*/
			User user = new User();
			user.setId(-1);
			int goodsNumber=0;
			int goods_id=0;
			Cart cart = new Cart();
			cart.setUser_id(user.getId());
			
			if(id!=null){
				goods_id = Integer.parseInt(id);
				cart.setGoods_id(goods_id);
			}
			if (number!=null) {
				goodsNumber =Integer.parseInt(number);
				System.out.println(goodsNumber);
				cart.setNum(goodsNumber);
			}
			//goodsNumber = cartService.getNumber(cart);
			System.out.println(goods_id);
			System.out.println(goodsNumber);
			
			cartService.updateGoodsNumber(cart);
			
			response.sendRedirect(request.getContextPath()+"/CartServlet");
	}           


	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
				doGet(request, response);
	
	}

}
