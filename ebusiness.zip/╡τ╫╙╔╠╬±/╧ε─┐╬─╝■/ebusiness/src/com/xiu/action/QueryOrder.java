package com.xiu.action;

import java.io.IOException;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.omg.CORBA.PRIVATE_MEMBER;

import com.heu.domain.Order;
import com.heu.domain.User;
import com.heu.factory.BasicFactory;
import com.heu.service.OrderService;
import com.heu.service.PersonalOrderService;
import com.xiu.service.MailInfoService;

/**
 * Servlet implementation class QueryOrder
 */
@WebServlet("/QueryOrder")
public class QueryOrder extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		User user = (User) request.getSession(false).getAttribute("User");

		// if query by order
		OrderService orderService = BasicFactory.getFactory().getService(
				OrderService.class);
		String order_id = ((ServletRequest) request.getSession(false))
				.getParameter("order_id");
		Order order = orderService.findOrderByOrderId(order_id);
		// else query by time VIP only
		PersonalOrderService personalOrderService = BasicFactory.getFactory()
				.getService(PersonalOrderService.class);
		String beginTime = request.getParameter("beginTime");
		String endTime = request.getParameter("endTime");
		List<Order> orders = personalOrderService.findPersonalOrdersByTime(
				beginTime, endTime);
		request.getSession().setAttribute("orderList", orders);
		request.getRequestDispatcher("/dispaly.jsp");
		

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
