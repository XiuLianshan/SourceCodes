package com.xiu.action;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.heu.domain.Goods;
import com.heu.domain.Order;
import com.heu.domain.User;
import com.heu.factory.BasicFactory;
import com.heu.service.OrderService;

public class CheckOutServlet extends HttpServlet {//���ﳵ����

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Map<Goods, Integer> cartMap = (Map<Goods, Integer>) request.getSession().getAttribute("map");
/*		User user = (User) request.getSession().getAttribute("user");
		if (user == null) {
			user = new User();
			user.setId(-1);
		}*/
		User user = new User();
		user.setId(2);
		double total_price = 0.0;
		Order order = new Order();
		order.setUser_id(user.getId());
		OrderService orderService = BasicFactory.getFactory().getService(
				OrderService.class);

		for (Entry<Goods, Integer> entry : cartMap.entrySet()) {// ����map
			total_price += entry.getKey().getPrice() * entry.getValue();
		}
		order.setTotal_price(total_price);
		order.setState("new");
		orderService.insertOrder(order);
		order = orderService.findOneOrder();

		request.getSession().setAttribute("order", order);
		response.sendRedirect(request.getContextPath()+"/front/pay.jsp");
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
