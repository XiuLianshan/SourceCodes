package com.xiu.action;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.heu.domain.Order;
import com.heu.factory.BasicFactory;
import com.heu.service.OrderService;
import com.sun.javafx.binding.StringFormatter;
import com.xiu.service.MailInfoService;

/**
 * Servlet implementation class PayServlet
 */
@WebServlet("/PayServlet")
public class PayServlet extends HttpServlet {
	// private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// �ύ�ʵ���Ϣ

		OrderService orderService = BasicFactory.getFactory().getService(
				OrderService.class);
		String address = request.getParameter("address");
		String telephone = request.getParameter("telephone");
		String name = request.getParameter("receiver");
		String postCode = request.getParameter("post_code");
		String postMethod = request.getParameter("method");
		String payMethod = request.getParameter("payMethod");
		System.out.println(address);
		int post = 100;
		if (postCode != null) {
			post = Integer.parseInt(postCode);
			System.out.println(post);
		}
		Order order = (Order) request.getSession().getAttribute("order");
		// System.out.println(order.getId());
		// System.out.println(order.getUser_id());
		order.setMessage(postMethod);// �����ʼķ�ʽ
		order.setPost_code(post);
		order.setPay_method(payMethod);
		order.setReceiver_name(name);
		order.setReceiver_address(address);
		order.setReceiver_tel(telephone);

		orderService.confirmOrder(order);

		request.getSession().setAttribute("order", order);
		response.sendRedirect(request.getContextPath() + "/payMethodSelect.jsp");
		System.out.println(order.getReceiver_address());
		// request.getRequestDispatcher("../payMethodSelect.jsp").forward(request,response);

	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
