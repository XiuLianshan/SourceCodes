package com.xiu.action;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.jsp.PageContext;

import com.heu.domain.Order;
import com.heu.domain.User;
import com.heu.factory.BasicFactory;
import com.heu.service.OrderService;

/**
 * Servlet implementation class CheckServlet
 */
@WebServlet("/CheckServlet")
public class CheckServlet extends HttpServlet {//��ͨ����


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			Order order = new Order();
			User user = (User) request.getSession().getAttribute("user");
			if(user!=null){
				order.setUser_id(user.getId());
			}
			else
			order.setUser_id(-1);//�����ο�
			OrderService orderService = BasicFactory.getFactory().getService(OrderService.class);
			//String goods_id=request.getParameter("goods_id");
		//	int goodsId=Integer.parseInt(goods_id);
			//��Ѱ��Ʒ�۸�
			
			//������Ǯ��
			double total_price = 200.0;
			order.setTotal_price(total_price);
			order.setState("new");
			//System.out.println(request);
			orderService.insertOrder(order);
		
            //	order = orderService.findOrderByOrderId();
      order = orderService.findOneOrder();
		//order = orderService.findOrderByOrderId(order_id)
			request.getSession().setAttribute("order", order);
		//	System.out.println(order);
			response.sendRedirect(request.getContextPath()+"/front/pay.jsp");
			//request.getRequestDispatcher("../pay.jsp").forward(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
