package com.xiu.action;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javafx.util.converter.NumberStringConverter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.heu.domain.Cart;
import com.heu.domain.Goods;
import com.heu.domain.Order;
import com.heu.domain.OrderItem;
import com.heu.domain.User;
import com.heu.factory.BasicFactory;
import com.xiu.service.CartService;
import com.xiu.service.OrderItemService;

/**
 * Servlet implementation class CartServlet
 */
@WebServlet("/CartServlet")
public class CartServlet extends HttpServlet {//�ȴ���ע���û��Ĺ��ﳵ��ɾ�Ĳ�����
	//2016/1/23���䣺Ŀ����д�깺�ﳵ����߼�

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		//	User user  = (User) request.getSession().getAttribute("user");
		Map<Goods, Integer>  map = new LinkedHashMap<Goods, Integer>();
		User user = new  User();
		user.setId(-1);
		List<Goods> goodsList = new ArrayList<Goods>();
		List<Integer> numbers = new ArrayList<Integer>();
			CartService cartService = BasicFactory.getFactory().getService(CartService.class);
			
		
			if(user!=null){
				goodsList = 	cartService.getGoodsInCart(user.getId());
				
				//request.getSession().setAttribute("goodList", goodsList);
				//request.getSession().setAttribute("numbers", numbers);
				for (Goods goods : goodsList) {
					Cart cart = new Cart();
					cart.setGoods_id(goods.getId());
					cart.setUser_id(user.getId());
					//numbers.add(cartService.getNumber(cart));
					//System.out.println("hehe nim");
					map.put(goods, cartService.getNumber(cart));
					//System.out.println("hehe nimabi");
				}
				request.getSession().setAttribute("map", map);
				//System.out.println(map);
				//System.out.println(goodsList);
				response.sendRedirect(request.getContextPath()+"/front/cart.jsp");//ת�������ﳵ��ʾҳ��
				
			}
			else {
				//�����ο͵��߼���Ŀǰû���뵽���õĽ��������
			}

	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
