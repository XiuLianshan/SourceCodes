package com.xiu.action;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.heu.domain.Cart;
import com.heu.domain.User;
import com.heu.factory.BasicFactory;
import com.xiu.service.CartService;

public class DelGoodsFromCart extends HttpServlet {

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request
	 *            the request send by the client to the server
	 * @param response
	 *            the response send by the server to the client
	 * @throws ServletException
	 *             if an error occurred
	 * @throws IOException
	 *             if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to
	 * post.
	 * 
	 * @param request
	 *            the request send by the client to the server
	 * @param response
	 *            the response send by the server to the client
	 * @throws ServletException
	 *             if an error occurred
	 * @throws IOException
	 *             if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		/*
		 * User user = (User) request.getSession().getAttribute("user"); if
		 * (user!=null) {
		 * 
		 * }
		 */
		CartService cartService = BasicFactory.getFactory().getService(CartService.class);
		User user = new User();
		user.setId(-1);
		String number = request.getParameter("id");
		int num=0;
		if (number!=null) {
			num=Integer.parseInt(number);
			Cart cart = new Cart();
			cart.setGoods_id(num);
			cart.setUser_id(user.getId());
			
			cartService.deleteGoodsFromCart(cart);
		}
		
		response.sendRedirect(request.getContextPath()+"/CartServlet");
System.out.println("fuck you ");
System.out.println(num);
	}

}
