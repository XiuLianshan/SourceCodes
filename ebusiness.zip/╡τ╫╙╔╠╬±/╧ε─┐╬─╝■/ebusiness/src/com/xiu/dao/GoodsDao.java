package com.xiu.dao;

import java.util.List;

import com.heu.dao.Dao;
import com.heu.domain.Goods;

public interface GoodsDao extends Dao {
	void insertGoods(Goods goods);

	List<Goods> getGoods();
}
