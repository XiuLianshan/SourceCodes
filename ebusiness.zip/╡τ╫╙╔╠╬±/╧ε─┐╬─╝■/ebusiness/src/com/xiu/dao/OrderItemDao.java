package com.xiu.dao;

import com.heu.dao.Dao;
import com.heu.domain.OrderItem;

public interface OrderItemDao extends Dao {
	void insertOrderItem(OrderItem o);

	OrderItem getOrderItem(int order_id,int goods_id);
}
