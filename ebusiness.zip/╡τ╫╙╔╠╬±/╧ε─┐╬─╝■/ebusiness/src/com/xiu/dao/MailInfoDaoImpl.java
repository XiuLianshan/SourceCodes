package com.xiu.dao;

import java.sql.SQLException;

import org.apache.commons.dbutils.DbUtils;
import org.apache.commons.dbutils.QueryRunner;

import com.heu.domain.Order;
import com.heu.util.TransactionManager;

public class MailInfoDaoImpl  implements MailInfoDao {

	@Override
	public void updateOrderMail(Order order) {
			//	DbUtils.loadDriver("");
				
				String sql = "update `order` set receiver_name=?, receiver_address=?,reveiver_tel=?  where id = ?";
				try {
					TransactionManager.startTran();
					QueryRunner queryRunner = new QueryRunner(TransactionManager.getSource());
					queryRunner.update(sql, order.getReceiver_name(),order.getReceiver_address(),order.getReceiver_tel());
					TransactionManager.commit();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					TransactionManager.rollback();
				}
		
		
	}

}
