package com.xiu.dao;

import java.util.List;

import com.heu.dao.Dao;
import com.heu.domain.Cart;
import com.heu.domain.Goods;

public interface CartDao extends Dao {
	void addGoods(Goods goods);

	void addCart(Cart cart);

	List<Goods> queryGoods(int user_id);

	void updateGoodsNumber(Cart cart);

	void deleteGoods(Goods goods);

	void deleteGoodsFromCart(Cart cart);
	
	void deleteCart(int user_id);
	
	int getNumber(Cart cart);
}
