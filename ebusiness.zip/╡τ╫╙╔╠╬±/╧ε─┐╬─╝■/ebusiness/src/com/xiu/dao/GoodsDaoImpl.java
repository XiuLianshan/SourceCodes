package com.xiu.dao;

import java.sql.SQLException;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import com.heu.domain.Goods;
import com.heu.util.TransactionManager;
import com.sun.org.apache.bcel.internal.generic.NEW;

public class GoodsDaoImpl implements GoodsDao {

	@Override
	public void insertGoods(Goods goods) {
		// TODO Auto-generated method stub
		String sql = "inset into `goods` () values()";
		try {
			QueryRunner queryRunner = new QueryRunner(
					TransactionManager.getSource());
			queryRunner.update(sql/* �п�����һЩ���� */);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	public List<Goods> getGoods() {
		// TODO Auto-generated method stub
		String sql = "select * from `goods`";
		try {
			QueryRunner queryRunner = new QueryRunner(
					TransactionManager.getSource());
			return queryRunner.query(sql, new BeanListHandler<Goods>(
					Goods.class));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}

}
