package com.xiu.dao;

import java.sql.SQLException;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import com.heu.domain.OrderItem;
import com.heu.util.TransactionManager;
import com.sun.org.apache.bcel.internal.generic.NEW;

public class OrderItemDaoImpl implements OrderItemDao {

	@Override
	public void insertOrderItem(OrderItem o) {
		// TODO Auto-generated method stub
		String sql = "insert into `order_item` (order_id,goods_id,num) values (?,?,?)";
		QueryRunner queryRunner;
		try {
			queryRunner = new QueryRunner(TransactionManager.getSource());
			queryRunner.update(sql, o.getOrder_id(), o.getGoods_id(),
					o.getNum());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	public OrderItem getOrderItem(int order_id, int goods_id) {

		String sql = "select * from `order_item` where order_item.order_id = orders.id "
				+ "and order_item.goods_id = goods.id and order_id =? and goods_id=?";
		try {
			QueryRunner queryRunner = new QueryRunner(
					TransactionManager.getSource());
			return queryRunner.query(sql, new BeanHandler<OrderItem>(
					OrderItem.class), order_id, goods_id)

			;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

}
