package com.xiu.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.jasper.tagplugins.jstl.core.ForEach;

import com.heu.domain.Cart;
import com.heu.domain.Goods;
import com.heu.util.TransactionManager;
//import com.sun.org.apache.bcel.internal.generic.NEW;
import com.sun.org.apache.bcel.internal.generic.NEW;
import com.sun.org.apache.regexp.internal.recompile;

public class CartDaoImpl implements CartDao {
	private List<Goods> goodsList = new ArrayList<Goods>();

	@Override
	public void addGoods(Goods goods) {
		goodsList.add(goods);

	}

	@Override
	public void addCart(Cart cart) {
		String sql = "insert into `cart` (user_id,goods_id,num) values (?,?,?)";
		try {
			QueryRunner queryRunner = new QueryRunner(
					TransactionManager.getSource());
			queryRunner.update(sql, cart.getUser_id(), cart.getGoods_id(),
					cart.getNum());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new RuntimeException(e);
		}
	}

	@Override
	public List<Goods> queryGoods(int user_id) {
		String sql = "select goods.* from   goods,cart where cart.goods_id = goods.id and cart.user_id =? ";
		try {
			QueryRunner queryRunner = new QueryRunner(
					TransactionManager.getSource());
			return queryRunner.query(sql, new BeanListHandler<Goods>(
					Goods.class), user_id);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}

	}

	@Override
	public void updateGoodsNumber(Cart cart) {

		String sql = ("update cart set num = ? where goods_id = ? and user_id = ?");
		try {
			QueryRunner queryRunner = new QueryRunner(
					TransactionManager.getSource());
			queryRunner.update(sql, cart.getNum(), cart.getGoods_id(),
					cart.getUser_id());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	public void deleteGoods(Goods goods) {

		goodsList.remove(goods);
	}

	@Override
	public void deleteGoodsFromCart(Cart cart) {
		String sql = "delete from `cart` where user_id=? and goods_id=?";
		try {
			QueryRunner queryRunner = new QueryRunner(
					TransactionManager.getSource());
			queryRunner.update(sql, cart.getUser_id(), cart.getGoods_id());
			System.out.println(cart.getUser_id());
			System.out.println(cart.getGoods_id());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	public void deleteCart(int user_id) {
		String sql = "delete from cart where user_id= ?";
		try {
			QueryRunner queryRunner = new QueryRunner(
					TransactionManager.getSource());
			queryRunner.update(sql, user_id);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	public int getNumber(Cart cart) {
		String sql = "select num from `cart` where goods_id=? and user_id = ?";
		Cart cart2 = new Cart();
		try {
			QueryRunner queryRunner = new QueryRunner(
					TransactionManager.getSource());
					cart2 = queryRunner.query(sql, new BeanHandler<Cart>(Cart.class),
					cart.getGoods_id(), cart.getUser_id());
			return cart2.getNum();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return 0;
		}

	}

}
