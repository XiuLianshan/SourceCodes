package com.xiu.dao;

import java.sql.SQLException;

import org.apache.commons.dbutils.QueryRunner;

import com.heu.domain.Order;
import com.heu.util.TransactionManager;

public class PayDaoImpl implements PayDao{

	@Override
	public void updatePayMethod(Order order) {
		// TODO Auto-generated method stub
			String sql = "update `order` set pay_method = ? where id  = ?";
			
			
			try {
				QueryRunner queryRunner = new QueryRunner(TransactionManager.getSource());
				queryRunner.update(sql, order.getPay_method(),order.getId());
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
	
	}

}
