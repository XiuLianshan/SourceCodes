package com.xiu.dao;

import com.heu.dao.Dao;
import com.heu.domain.Order;

public interface PayDao extends Dao{
		void updatePayMethod(Order order);
}
