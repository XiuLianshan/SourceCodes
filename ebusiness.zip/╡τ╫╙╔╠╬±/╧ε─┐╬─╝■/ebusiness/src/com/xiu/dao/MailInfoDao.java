package com.xiu.dao;

import com.heu.dao.Dao;
import com.heu.domain.Order;

public interface MailInfoDao  extends Dao{
		void updateOrderMail(Order order);
}
