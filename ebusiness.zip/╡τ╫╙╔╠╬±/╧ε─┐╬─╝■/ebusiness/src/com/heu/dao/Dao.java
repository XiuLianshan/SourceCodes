package com.heu.dao;

public interface Dao {

}
