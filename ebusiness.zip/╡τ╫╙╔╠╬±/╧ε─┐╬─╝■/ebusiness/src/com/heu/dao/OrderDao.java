package com.heu.dao;

import java.util.List;

import com.heu.domain.Order;

public interface OrderDao extends Dao {

	Order findOrderByUserId(String user_id);

	Order findOrderByOrderId(String order_id);

	List<Order> findOrderByState(String state);

	void updateStateByOrderId(String order_id, String newState);

	Order findOrderByOrderIdAndState(String order_id, String state);

	List<Order> findAllOrders();

	void deleteOrderByOrderId(String order_id);
	
	void insertOrder(Order order);
	
	void updateOrder(Order order);

	void deleteOrderItemByOrderId(String order_id);

	List<Order> findOrderByUserId(int user_id);
	
	Order findLatestOrder();

}
