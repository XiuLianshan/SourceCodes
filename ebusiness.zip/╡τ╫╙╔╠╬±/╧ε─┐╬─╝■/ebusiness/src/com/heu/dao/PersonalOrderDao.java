package com.heu.dao;

import java.util.Date;
import java.util.List;

import com.heu.domain.Order;



public interface PersonalOrderDao extends  Dao {
	List<Order> findPersonalOrdersByTime(Date timeBegin,Date timeEnd);
}
