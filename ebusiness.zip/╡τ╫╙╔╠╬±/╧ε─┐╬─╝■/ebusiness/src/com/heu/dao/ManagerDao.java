package com.heu.dao;

import java.util.List;

import com.heu.domain.Manager;

public interface ManagerDao extends Dao {

	Manager findManagerByIdAndPwd(String username, String password);

	void updatePwdByName(String manager_name,String newPwd);

	Manager findManagerByName(String manager_name);

	void addManager(Manager manager);

	List<Manager> findAllManagers();

}
