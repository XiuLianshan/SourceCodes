package com.heu.action;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Timestamp;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.heu.domain.Order;
import com.heu.factory.BasicFactory;
import com.heu.service.OrderService;

public class OrderUpdateServlet extends HttpServlet {

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String newState=request.getParameter("newState");
		String order_id=request.getParameter("order_id");
		OrderService service=BasicFactory.getFactory().getService(OrderService.class);
		Order order=null;
		
		order=service.findOrderByOrderId(order_id);
		
		if (order.getState().equals("new") && newState.equals("paid") && order.getPay_state().equals("paid")) {
			service.updateStateByOrderId(order_id,newState);
		}else if (order.getState().equals("paid") && newState.equals("deliver")) {
			service.updateStateByOrderId(order_id,newState);
		}else if (newState.equals("cancel") && order.getState().equals("new")) {
			service.updateStateByOrderId(order_id,newState);
		}else {
			request.setAttribute("message", "������ô�޸Ķ���״̬��~");
			request.getRequestDispatcher("/orderQuery.jsp").forward(request, response);
		}
		String queryCondition=(String) request.getSession().getAttribute("queryCondition");
		if (queryCondition.split(":")[0].equals("order_id")) {
			request.getRequestDispatcher("/OrderQueryServlet?order_id="+queryCondition.split(":")[1]).forward(request, response);
		}else {
			request.getRequestDispatcher("/OrderQueryServlet?state="+queryCondition.split(":")[1]).forward(request, response);
		}
		
//		response.getWriter().write("�޸ĳɹ�~");
//		response.setHeader("Refresh", "3;url="+request.getContextPath()+"/servlet/OrderQueryServlet");
		
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doGet(request, response);
	}

}
