package com.heu.action;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.heu.domain.Order;
import com.heu.factory.BasicFactory;
import com.heu.service.OrderService;

public class OrderQueryServlet extends HttpServlet {

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String state=request.getParameter("state");
		String order_id=request.getParameter("order_id");
		OrderService service=BasicFactory.getFactory().getService(OrderService.class);
		List<Order> orders=new ArrayList<Order>();
		Order order=null;
		
		if (state==null && order_id!=null) {
			order=service.findOrderByOrderId(order_id);
			orders.add(order);
			request.getSession().setAttribute("queryCondition","order_id:"+order_id);
		}else if(state!=null && order_id==null){
			orders=service.findOrderByState(state);
			request.getSession().setAttribute("queryCondition", "state"+state);
		}else if (state!=null && order_id!=null) {
			orders=(List<Order>) service.findOrderByOrderIdAndState(order_id,state);
		}else if (state==null && order_id==null) {
			orders=service.findAllOrders();
		}
		
		request.setAttribute("orders", orders);
		request.getRequestDispatcher("/orderQuery.jsp").forward(request, response);
		
		
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doGet(request, response);
	}

}
