package com.heu.action;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.heu.domain.User;
import com.heu.factory.BasicFactory;
import com.heu.service.UserService;

public class FindPwdServlet extends HttpServlet {

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		User user=null;
		UserService service=BasicFactory.getFactory().getService(UserService.class);
		String username=request.getParameter("username");
		String qno=request.getParameter("question_no");
		String qAnswer=request.getParameter("qustion_answer");
		String newPwd=request.getParameter("new_password");
		user=service.findUserByName(username);
		//user with wrong username cannot change password
		if (user==null) {
			request.setAttribute("message", "��������Ǵ�����û���");
			request.getRequestDispatcher("/pwdFind.jsp").forward(request, response);
			return;
		}else {
			//user with wrong question answers cannot change password
			if (!user.getQustion_answer().equals(qAnswer)) {
				request.setAttribute("mesage", "��������ܱ�����ش����");
				request.getRequestDispatcher("/pwdFind.jsp").forward(request, response);
				return;
			} else {
				//update password to the new one
				service.changePWDbyId(user.getId(),newPwd);
			}
		}
		//login he user with new password
		user=service.findUserByName(username);
		request.getSession().setAttribute("user", user);
		
		response.sendRedirect("/index.jsp");
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doGet(request, response);
	}

}
