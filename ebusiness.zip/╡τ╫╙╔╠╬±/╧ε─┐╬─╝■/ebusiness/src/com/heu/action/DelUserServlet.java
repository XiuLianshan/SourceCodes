package com.heu.action;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.heu.domain.Order;
import com.heu.domain.User;
import com.heu.factory.BasicFactory;
import com.heu.service.OrderService;
import com.heu.service.UserService;

public class DelUserServlet extends HttpServlet {

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String username=request.getParameter("username");
		String id_card=request.getParameter("id_card");
		UserService userService=BasicFactory.getFactory().getService(UserService.class);
		OrderService orderService=BasicFactory.getFactory().getService(OrderService.class);
		User user=null;
		Order order=null;
		
		user=userService.findUserByName(username);
		
		order=orderService.findOrderByUserId(user.getUsername());
		String userQueryCon=(String) request.getSession().getAttribute("userQueryCon");
		
		if (order!=null) {
			request.setAttribute("message", "���û�ӵ�ж�����Ϣ������ɾ�����û���");
			if (userQueryCon.split(":")[0].equals("id_card")) {
				request.getRequestDispatcher("/UserQuerySerlet?id_card="+userQueryCon.split(":")[1]).forward(request, response);
			}else {
				request.getRequestDispatcher("/UserQuerySerlet?username="+userQueryCon.split(":")[1]).forward(request, response);
			}
		}else {
			userService.delUser(user.getId());
//			request.setAttribute("message", "�����û��Ѿ���ʧ��...");
//			request.getRequestDispatcher("/userqueryjsp").forward(request, response);
//			response.getWriter().write("�����û��Ѿ���ʧ��...");
//			response.setHeader("Refresh", "3;url="+request.getContextPath()+"/servlet/UserQuerySerlet");
			if (userQueryCon.split(":")[0].equals("id_card")) {
				request.getRequestDispatcher("/UserQuerySerlet?id_card="+userQueryCon.split(":")[1]).forward(request, response);
			}else {
				request.getRequestDispatcher("/UserQuerySerlet?username="+userQueryCon.split(":")[1]).forward(request, response);
			}
		}
		
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doGet(request, response);
	}

}
