package com.heu.action;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.heu.domain.User;
import com.heu.factory.BasicFactory;
import com.heu.service.UserService;

public class UserQuerySerlet extends HttpServlet {

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String username=request.getParameter("username");
		String id_card=request.getParameter("id_card");
		UserService service=BasicFactory.getFactory().getService(UserService.class);
		User user=null;
		
		if (username==null) {
			user=service.findUserByIdcard(Integer.parseInt(id_card));
			if (user==null) {
				request.setAttribute("message", "ָ���û�������~");
				request.getRequestDispatcher("/userquery.jsp").forward(request, response);
			}else {
				request.setAttribute("user", user);
				request.getSession().setAttribute("userQueryCon", "id_card:"+id_card);
				request.getRequestDispatcher("/userquery.jsp").forward(request, response);
				
			}
		}else {
			user=service.findUserByName(username);
			if (user==null) {
				request.setAttribute("message", "ָ���û�������~");
				request.getRequestDispatcher("/userquery.jsp").forward(request, response);
			}else {
				request.setAttribute("user", user);
				request.getSession().setAttribute("userQueryCon", "username:"+username);
				request.getRequestDispatcher("/userquery.jsp").forward(request, response);
			}
		}
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doGet(request, response);
	}

}
