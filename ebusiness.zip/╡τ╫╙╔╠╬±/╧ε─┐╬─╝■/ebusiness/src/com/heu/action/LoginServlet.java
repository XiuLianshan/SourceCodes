package com.heu.action;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLEncoder;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.heu.domain.User;
import com.heu.factory.BasicFactory;
import com.heu.service.UserService;
import com.heu.serviceImpl.UserServiceImpl;

public class LoginServlet extends HttpServlet {

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String username=request.getParameter("username");
		String password=request.getParameter("password");
		
		UserService service=BasicFactory.getFactory().getService(UserService.class);
		
		User user=service.findUserByIdAndPwd(username,password);
		if (user==null) {
			request.setAttribute("message", "�û����������벻��ȷ");
			request.getRequestDispatcher("/login.jsp").forward(request, response);
			return;
		}
		request.getSession().setAttribute("user", user);
		
		//autologin use session
		if ("true".equals(request.getParameter("autologin"))) {
			Cookie autologincCookie=new Cookie("autologin", URLEncoder.encode(username+":"+password,"UTF-8"));
			autologincCookie.setPath("/");
			autologincCookie.setMaxAge(3600*24*30);
			response.addCookie(autologincCookie);
		}
		
		response.sendRedirect(request.getContextPath()+"/index.jsp");
		
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doGet(request, response);
	}

}
