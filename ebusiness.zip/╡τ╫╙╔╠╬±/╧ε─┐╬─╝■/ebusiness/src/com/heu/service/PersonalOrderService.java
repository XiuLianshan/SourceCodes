package com.heu.service;

import java.util.Date;
import java.util.List;

import com.heu.domain.Order;

public interface PersonalOrderService extends Service {
	List<Order> findPersonalOrdersByTime(String beginTime, String endTime);

	Order findPersonalOrderByOrderId(int order_id);
}
