package com.heu.service;

public interface Service {

}
