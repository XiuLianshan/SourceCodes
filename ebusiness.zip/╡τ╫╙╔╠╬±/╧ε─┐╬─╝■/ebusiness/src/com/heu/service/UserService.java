package com.heu.service;

import com.heu.domain.User;

public interface UserService extends Service {

	User findUserByIdAndPwd(String username, String password);

	void regist(User user);

	User findUserByName(String username);

	void changePWDbyId(int id, String newPwd);

	User findUserById(String id);

	User findUserByIdcard(int parseInt);

	//transanction required
	void delUser(int id);

}
