package com.heu.service;

import java.util.List;

import com.heu.domain.Order;

public interface OrderService extends Service {

	Order findOrderByUserId(String username);

	Order findOrderByOrderId(String order_id);

	List<Order> findOrderByState(String state);

	void updateStateByOrderId(String order_id, String newState);

	Order findOrderByOrderIdAndState(String order_id, String state);

	List<Order> findAllOrders();

	void deleteOrderByOrderId(String order_id);
	
	void insertOrder(Order order);
	
	void confirmOrder(Order order);

	List<Order> findOrderByUserId(int user_id);
	
	Order findOneOrder();

}
