package com.heu.service;

import java.util.List;

import com.heu.domain.Manager;

public interface ManagerService extends Service {

	Manager findManagerByIdAndPwd(String username, String password);

	void updatePwdByName(String manager_name,String newPwd);

	void addManager(Manager manager);

	Manager findManagerByName(String manager_name);

	List<Manager> findAllManagers();

}
