package com.heu.serviceImpl;

import java.util.List;

import com.heu.dao.ManagerDao;
import com.heu.domain.Manager;
import com.heu.factory.BasicFactory;
import com.heu.service.ManagerService;

public class ManagerServiceImpl implements ManagerService {

	ManagerDao dao=BasicFactory.getFactory().getDao(ManagerDao.class);
	
	@Override
	public Manager findManagerByIdAndPwd(String username, String password) {
		// TODO Auto-generated method stub
		return dao.findManagerByIdAndPwd(username,password);
	}

	@Override
	public void updatePwdByName(String manager_name,String newPwd) {
		// TODO Auto-generated method stub
		dao.updatePwdByName(manager_name,newPwd);
	}

	@Override
	public void addManager(Manager manager) {
		// TODO Auto-generated method stub
		dao.addManager(manager);
	}

	@Override
	public Manager findManagerByName(String manager_name) {
		// TODO Auto-generated method stub
		return dao.findManagerByName(manager_name);
	}

	@Override
	public List<Manager> findAllManagers() {
		// TODO Auto-generated method stub
		return dao.findAllManagers();
	}

}
