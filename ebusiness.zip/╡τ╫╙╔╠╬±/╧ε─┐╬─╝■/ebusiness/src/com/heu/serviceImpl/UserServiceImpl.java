package com.heu.serviceImpl;

import com.heu.dao.UserDao;
import com.heu.daoImpl.UserDaoImpl;
import com.heu.domain.User;
import com.heu.factory.BasicFactory;
import com.heu.service.UserService;

public class UserServiceImpl implements UserService {

	UserDao dao=BasicFactory.getFactory().getDao(UserDao.class);
	@Override
	public User findUserByIdAndPwd(String username, String password) {
		return dao.findUserByIdAndPwd(username,password);
	}
	@Override
	public void regist(User user) {
		// TODO Auto-generated method stub
		if (dao.findUserByName(user.getUsername())!=null) {
			throw new RuntimeException("�û����Ѿ�����!!");
		}
		user.setFund(0);
		user.setTotal_consumption(0);
		user.setVIP_level(0);
		dao.regist(user);
	}
	@Override
	public User findUserByName(String username) {
		// TODO Auto-generated method stub
		return dao.findUserByName(username);
	}
	@Override
	public void changePWDbyId(int id, String newPwd) {
		// TODO Auto-generated method stub
		dao.changePWDbyId(id,newPwd);
	}
	@Override
	public User findUserById(String id) {
		// TODO Auto-generated method stub
		return dao.findUserById(id);
	}
	@Override
	public User findUserByIdcard(int id_card) {
		// TODO Auto-generated method stub
		return dao.findUserByIdcard(id_card);
	}
	
	@Override
	public void delUser(int id) {
		
		//delete relative cart info
		
		//delete user
		dao.delUser(id);
		
	}

}
