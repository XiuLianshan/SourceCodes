package com.heu.serviceImpl;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import com.heu.dao.OrderDao;
import com.heu.dao.PersonalOrderDao;
import com.heu.daoImpl.PersonalOrderDaoImpl;
import com.heu.domain.Order;
import com.heu.service.PersonalOrderService;

public class PersonalOrderServiceImpl implements PersonalOrderService {
	private PersonalOrderDao personalOrderDao = new PersonalOrderDaoImpl();
	private OrderDao OrderDao = null;

	@Override
	public List<Order> findPersonalOrdersByTime(String beginTime, String endTime) {
		// TODO Auto-generated method stub
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date begin ;
		Date end;
		try {
			begin= dateFormat.parse(beginTime);
			end = dateFormat.parse(endTime);
			return personalOrderDao.findPersonalOrdersByTime(begin, end);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
			}
			
		
	}

	@Override
	public Order findPersonalOrderByOrderId(int order_id) {
		// TODO Auto-generated method stub
		String id = order_id + "";
		return OrderDao.findOrderByOrderId(id);
	}

}
