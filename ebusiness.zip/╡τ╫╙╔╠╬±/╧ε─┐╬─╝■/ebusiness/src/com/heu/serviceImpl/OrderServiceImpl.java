package com.heu.serviceImpl;

import java.util.List;

import com.heu.annotation.Tran;
import com.heu.dao.OrderDao;
import com.heu.domain.Order;
import com.heu.factory.BasicFactory;
import com.heu.service.OrderService;

public class OrderServiceImpl implements OrderService {

	OrderDao dao=BasicFactory.getFactory().getDao(OrderDao.class);
	
	@Override
	public List<Order> findOrderByUserId(int user_id) {
		// TODO Auto-generated method stub
		return dao.findOrderByUserId(user_id);
	}

	@Override
	public Order findOrderByOrderId(String order_id) {
		// TODO Auto-generated method stub
		return dao.findOrderByOrderId(order_id);
	}

	@Override
	public List<Order> findOrderByState(String state) {
		// TODO Auto-generated method stub
		return dao.findOrderByState(state);
	}

	@Override
	public void updateStateByOrderId(String order_id, String newState) {
		// TODO Auto-generated method stub
		dao.updateStateByOrderId(order_id,newState);
	}

	@Override
	public Order findOrderByOrderIdAndState(String order_id, String state) {
		// TODO Auto-generated method stub
		return dao.findOrderByOrderIdAndState(order_id,state);
	}

	@Override
	public List<Order> findAllOrders() {
		// TODO Auto-generated method stub
		return dao.findAllOrders();
	}

	@Override
	@Tran
	public void deleteOrderByOrderId(String order_id) {
		// TODO Auto-generated method stub
		//dao.deleteOrderItemByOrderId(order_id);
		dao.deleteOrderByOrderId(order_id);
	}

	@Override
	public Order findOrderByUserId(String username) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public void insertOrder(Order order) {
		// TODO Auto-generated method stub
		dao.insertOrder(order);
	}

	@Override
	public void confirmOrder(Order order) {
		// TODO Auto-generated method stub
		dao.updateOrder(order);
	}

	@Override
	public Order findOneOrder() {
		// TODO Auto-generated method stub
		return dao.findLatestOrder();
	}

}
