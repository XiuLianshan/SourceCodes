package com.heu.test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.commons.dbutils.QueryRunner;

import com.heu.util.TransactionManager;
import com.sun.org.apache.bcel.internal.generic.Select;

public class C3P0Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

//		String sql="insert into type1 values(?,?)";
//		try {
//			QueryRunner runner=new QueryRunner(TransactionManager.getSource());
//			runner.update(sql, 222,"no");
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		
		String sql="select * from `order` ";
		try {
        	Class.forName("com.mysql.jdbc.Driver");
    		Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/e","root","jiaju19621993");
            PreparedStatement pstmt=conn.prepareStatement(sql);
//            pstmt.setString(1, username);
//            pstmt.setString(2,password);
            ResultSet rs= pstmt.executeQuery();
           
            while (rs.next()) {
				System.out.println(rs.getInt(1));
			}
            rs.close();
            pstmt.close();
            conn.close();
        } catch (Exception ex) {
        	ex.printStackTrace();
        	throw new RuntimeException();
        }
	
		
		
	}

}
