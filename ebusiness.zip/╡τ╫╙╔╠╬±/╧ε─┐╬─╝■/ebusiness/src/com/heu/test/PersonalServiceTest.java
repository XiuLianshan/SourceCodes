package com.heu.test;

import java.util.Date;
import java.util.List;

import org.junit.Test;

import com.heu.domain.Order;
import com.heu.service.OrderService;
import com.heu.service.PersonalOrderService;
import com.heu.serviceImpl.OrderServiceImpl;
import com.heu.serviceImpl.PersonalOrderServiceImpl;

public class PersonalServiceTest {
	@Test
	public void fun1() {
	
	}
	@Test
	 public void fun22(){
		 List<Order> orders ;
		 OrderService orderService = new OrderServiceImpl();
		 orders=orderService.findAllOrders();
		 System.out.println(orders);
	}
}
