package com.heu.domain;

import java.io.Serializable;

public class Type2 implements Serializable{

	private int id;
	private String type_name;
	private int type1_id;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getType_name() {
		return type_name;
	}
	public void setType_name(String type_name) {
		this.type_name = type_name;
	}
	public int getType1_id() {
		return type1_id;
	}
	public void setType1_id(int type1_id) {
		this.type1_id = type1_id;
	}
	
	
}
