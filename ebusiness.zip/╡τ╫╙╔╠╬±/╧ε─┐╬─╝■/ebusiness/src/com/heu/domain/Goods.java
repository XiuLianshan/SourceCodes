package com.heu.domain;

import java.io.Serializable;

public class Goods implements Serializable{

	private int id;
	private String goods_name;
	private int type1_id;
	private int type2_id;
	private double price;
	private String image_url;
	private int stock;
	private String description;
	private int sold_number;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getGoods_name() {
		return goods_name;
	}
	public void setGoods_name(String goods_name) {
		this.goods_name = goods_name;
	}
	public int getType1_id() {
		return type1_id;
	}
	public void setType1_id(int type1_id) {
		this.type1_id = type1_id;
	}
	public int getType2_id() {
		return type2_id;
	}
	public void setType2_id(int type2_id) {
		this.type2_id = type2_id;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public String getImage_url() {
		return image_url;
	}
	public void setImage_url(String image_url) {
		this.image_url = image_url;
	}
	public int getStock() {
		return stock;
	}
	public void setStock(int stock) {
		this.stock = stock;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getSold_number() {
		return sold_number;
	}
	public void setSold_number(int sold_number) {
		this.sold_number = sold_number;
	}
	
	
}
