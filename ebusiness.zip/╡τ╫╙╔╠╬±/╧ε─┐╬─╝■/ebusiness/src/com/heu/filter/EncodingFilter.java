package com.heu.filter;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;

/**
 * Created by XiuLianshan on 2015/12/23.
 */
@WebFilter(filterName = "EncodingFilter")
public class EncodingFilter implements Filter {
    public void destroy() {

    }

    public void doFilter(ServletRequest request, ServletResponse response,
                         FilterChain chain) throws IOException, ServletException {
      
        response.setCharacterEncoding("UTF-8");
    
        request.setCharacterEncoding("utf-8");

        HttpServletRequest req = (HttpServletRequest) request;

		/*
		 * 处理GET请求的编码问�?
		 */
//		String username = request.getParameter("username");
//		username = new String(username.getBytes("ISO-8859-1"), "UTF-8");

        if(req.getMethod().equals("GET")) {
            EncodingRequest er = new EncodingRequest(req);
            chain.doFilter(er, response);
        } else if(req.getMethod().equals("POST")) {
            chain.doFilter(request, response);
        }
    }

    public void init(FilterConfig fConfig) throws ServletException {

    }
}


