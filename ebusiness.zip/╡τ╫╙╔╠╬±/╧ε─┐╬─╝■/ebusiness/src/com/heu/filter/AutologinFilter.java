package com.heu.filter;

import java.io.IOException;
import java.net.URLDecoder;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.heu.domain.User;
import com.heu.factory.BasicFactory;
import com.heu.service.UserService;

public class AutologinFilter implements Filter {

	@Override
	public void destroy() {
		// TODO Auto-generated method stub

	}

	@Override
	public void doFilter(ServletRequest req, ServletResponse res,
			FilterChain chain) throws IOException, ServletException {
		// TODO Auto-generated method stub

		Cookie findCookie=null;
		HttpServletRequest request=(HttpServletRequest) req;
		HttpServletResponse response=(HttpServletResponse) res;
		if (request.getSession(false)==null || request.getSession().getAttribute("user")==null) {
			Cookie[] cookies=request.getCookies();
			if (cookies!=null) {
				for (Cookie cookie : cookies) {
					if (cookie.getName().equals("autologin")) {
						findCookie=cookie;
						break;
					}
				}
			}
			
			
			if (findCookie!=null) {
				String value=URLDecoder.decode(findCookie.getValue(), "UTF-8");
				String username=value.split(":")[0];
				String password=value.split(":")[1];
				UserService service=BasicFactory.getFactory().getService(UserService.class);
				User user=service.findUserByIdAndPwd(username, password);
				request.getSession().setAttribute("user", user);
			}
		}
		
		chain.doFilter(req, res);
	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
		// TODO Auto-generated method stub

	}

}
