package com.heu.daoImpl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import com.heu.dao.UserDao;
import com.heu.domain.User;
import com.heu.util.TransactionManager;
import com.sun.org.apache.bcel.internal.generic.NEW;

public class UserDaoImpl implements UserDao {

	@Override
	public User findUserByIdAndPwd(String username, String password) {
		String sql="select * from user where username=? and password=?";
		try {
			QueryRunner runner=new QueryRunner(TransactionManager.getSource());
			return runner.query(sql, new BeanHandler<User>(User.class), username,password);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			throw new RuntimeException();
		}
//		User user=null;
//		try {
//        	Class.forName("oracle.jdbc.driver.OracleDriver");
//    		Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:liang","liang","liang");
//            PreparedStatement pstmt=conn.prepareStatement(sql);
//            pstmt.setString(1, username);
//            pstmt.setString(2,password);
//            ResultSet rs= pstmt.executeQuery();
//            if (rs.wasNull()) {
//				return null;
//			}
//            while (rs.next()) {
//				user.setId(rs.getInt(1));
//				user.setUsername(rs.getString(2));
//				user.setPassword(rs.getString(3));
//				user.setReal_name(rs.getString(4));
//				user.setId_card(rs.getInt(5));
//				user.setEmail(rs.getString(6));
//				user.setPost_code(rs.getInt(7));
//				user.setAddress(rs.getString(8));
//				user.setTelephone(rs.getString(9));
//				user.setLast_login_time(rs.getTimestamp(10));
//				user.setTotal_consumption(rs.getDouble(11));
//				user.setVIP_level(rs.getInt(12));
//				user.setQuestion_no(rs.getString(13));
//				user.setQustion_answer(rs.getString(14));
//				user.setFund(rs.getDouble(15));
//				user.setHead_img(rs.getString(16));
//				
//			}
//            rs.close();
//            pstmt.close();
//            conn.close();
//        } catch (Exception ex) {
//        	ex.printStackTrace();
//        	throw new RuntimeException();
//        }
//		return user;
	}

	@Override
	public void regist(User user) {
		// TODO Auto-generated method stub
		String sql="insert into user values(null,?,?,?,?,?,?,?,?,null,?,?,?,?,?,?)";
		
		try {
			QueryRunner runner=new QueryRunner(TransactionManager.getSource());
			runner.update(sql, user.getUsername(),user.getPassword(),user.getReal_name(),user.getId_card(),user.getEmail(),
					user.getPost_code(),user.getAddress(),user.getTelephone(),user.getTotal_consumption(),user.getVIP_level(),
					user.getQuestion_no(),user.getQustion_answer(),user.getFund(),user.getHead_img());
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
//		try {
//        	Class.forName("oracle.jdbc.driver.OracleDriver");
//    		Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:liang","liang","liang");
//            PreparedStatement pstmt=conn.prepareStatement(sql);
//            pstmt.setString(1, user.getUsername());
//            pstmt.setString(2,user.getPassword());
//            pstmt.setString(3,user.getReal_name());
//            pstmt.setInt(4,user.getId_card());
//            pstmt.setString(5,user.getEmail());
//            pstmt.setInt(6,user.getPost_code());
//            pstmt.setString(7,user.getAddress());
//            pstmt.setString(8,user.getTelephone());
//            pstmt.setDouble(9,user.getTotal_consumption());
//            pstmt.setInt(10,user.getVIP_level());
//            pstmt.setString(11,user.getQuestion_no());
//            pstmt.setString(12,user.getQustion_answer());
//            pstmt.setDouble(14,user.getFund());
//            pstmt.setString(15,user.getHead_img());
//            
//            int i=pstmt.executeUpdate();
//           // rs.close();
//            pstmt.close();
//            conn.close();
//        } catch (Exception ex) {
//        	ex.printStackTrace();
//        	throw new RuntimeException();
//        }
		
	}

	@Override
	public User findUserByName(String username) {
		String sql="select * from user where username=?";
		try {
			QueryRunner runner=new QueryRunner(TransactionManager.getSource());
			return runner.query(sql, new BeanHandler<User>(User.class), username);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			throw new RuntimeException();
		}
//		User user=null;
//		try {
//        	Class.forName("oracle.jdbc.driver.OracleDriver");
//    		Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:liang","liang","liang");
//            PreparedStatement pstmt=conn.prepareStatement(sql);
//            pstmt.setString(1, username);
//            
//            ResultSet rs= pstmt.executeQuery();
//            if (rs.wasNull()) {
//				return null;
//			}
//            while (rs.next()) {
//				user.setId(rs.getInt(1));
//				user.setUsername(rs.getString(2));
//				user.setPassword(rs.getString(3));
//				user.setReal_name(rs.getString(4));
//				user.setId_card(rs.getInt(5));
//				user.setEmail(rs.getString(6));
//				user.setPost_code(rs.getInt(7));
//				user.setAddress(rs.getString(8));
//				user.setTelephone(rs.getString(9));
//				user.setLast_login_time(rs.getTimestamp(10));
//				user.setTotal_consumption(rs.getDouble(11));
//				user.setVIP_level(rs.getInt(12));
//				user.setQuestion_no(rs.getString(13));
//				user.setQustion_answer(rs.getString(14));
//				user.setFund(rs.getDouble(15));
//				user.setHead_img(rs.getString(16));
//				
//			}
//            rs.close();
//            pstmt.close();
//            conn.close();
//        } catch (Exception ex) {
//        	ex.printStackTrace();
//        	throw new RuntimeException(); 
//        }
//		return user;
	}

	@Override
	public void changePWDbyId(int id, String newPwd) {
		// TODO Auto-generated method stub
		String sql="update user set password=? where id=?";
		try {
			QueryRunner runner=new QueryRunner(TransactionManager.getSource());
			runner.update(sql, newPwd,id);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
//		try {
//        	Class.forName("oracle.jdbc.driver.OracleDriver");
//    		Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:liang","liang","liang");
//            PreparedStatement pstmt=conn.prepareStatement(sql);
//            pstmt.setInt(1, id);
//            pstmt.setString(2,newPwd);
//            pstmt.executeUpdate();
//          
//            pstmt.close();
//            conn.close();
//        } catch (Exception ex) {
//        	ex.printStackTrace();
//        	throw new RuntimeException();
//        }
	}

	@Override
	public User findUserById(String id) {
		// TODO Auto-generated method stub
		String sql="select * from user where id=?";
		try {
			QueryRunner runner=new QueryRunner(TransactionManager.getSource());
			return runner.query(sql, new BeanHandler<User>(User.class), id);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
//		User user=null;
//		try {
//        	Class.forName("oracle.jdbc.driver.OracleDriver");
//    		Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:liang","liang","liang");
//            PreparedStatement pstmt=conn.prepareStatement(sql);
//            pstmt.setString(1, id);
//            ResultSet rs= pstmt.executeQuery();
//            if (rs.wasNull()) {
//				return null;
//			}
//            while (rs.next()) {
//				user.setId(rs.getInt(1));
//				user.setUsername(rs.getString(2));
//				user.setPassword(rs.getString(3));
//				user.setReal_name(rs.getString(4));
//				user.setId_card(rs.getInt(5));
//				user.setEmail(rs.getString(6));
//				user.setPost_code(rs.getInt(7));
//				user.setAddress(rs.getString(8));
//				user.setTelephone(rs.getString(9));
//				user.setLast_login_time(rs.getTimestamp(10));
//				user.setTotal_consumption(rs.getDouble(11));
//				user.setVIP_level(rs.getInt(12));
//				user.setQuestion_no(rs.getString(13));
//				user.setQustion_answer(rs.getString(14));
//				user.setFund(rs.getDouble(15));
//				user.setHead_img(rs.getString(16));
//				
//			}
//            rs.close();
//            pstmt.close();
//            conn.close();
//        } catch (Exception ex) {
//        	ex.printStackTrace();
//        	throw new RuntimeException();
//        }
//		return user;
	}

	@Override
	public User findUserByIdcard(int id_card) {
		// TODO Auto-generated method stub
		String sql="select * from user where id_card=?";
		try {
			QueryRunner runner=new QueryRunner(TransactionManager.getSource());
			return runner.query(sql, new BeanHandler<User>(User.class), id_card);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
//		User user=null;
//		try {
//        	Class.forName("oracle.jdbc.driver.OracleDriver");
//    		Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:liang","liang","liang");
//            PreparedStatement pstmt=conn.prepareStatement(sql);
//            pstmt.setInt(1, id_card);
//            ResultSet rs= pstmt.executeQuery();
//            if (rs.wasNull()) {
//				return null;
//			}
//            while (rs.next()) {
//				user.setId(rs.getInt(1));
//				user.setUsername(rs.getString(2));
//				user.setPassword(rs.getString(3));
//				user.setReal_name(rs.getString(4));
//				user.setId_card(rs.getInt(5));
//				user.setEmail(rs.getString(6));
//				user.setPost_code(rs.getInt(7));
//				user.setAddress(rs.getString(8));
//				user.setTelephone(rs.getString(9));
//				user.setLast_login_time(rs.getTimestamp(10));
//				user.setTotal_consumption(rs.getDouble(11));
//				user.setVIP_level(rs.getInt(12));
//				user.setQuestion_no(rs.getString(13));
//				user.setQustion_answer(rs.getString(14));
//				user.setFund(rs.getDouble(15));
//				user.setHead_img(rs.getString(16));
//				
//			}
//            rs.close();
//            pstmt.close();
//            conn.close();
//        } catch (Exception ex) {
//        	ex.printStackTrace();
//        	throw new RuntimeException();
//        }
//		return user;
		return null;
	}

	@Override
	public void delUser(int id) {
		// TODO Auto-generated method stub
		String sql1="delete from user where id=?";
		String sql2="delete from cart where user_id=?";
		
		try {
			QueryRunner runner=new QueryRunner(TransactionManager.getSource());
			runner.update(sql2, id);
			runner.update(sql1,id);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
//		try {
//        	Class.forName("oracle.jdbc.driver.OracleDriver");
//    		Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:liang","liang","liang");
//            PreparedStatement pstmt=conn.prepareStatement(sql);
//            pstmt.setInt(1, id);
//            pstmt.executeUpdate();
//          
//            pstmt.close();
//            conn.close();
//        } catch (Exception ex) {
//        	ex.printStackTrace();
//        	throw new RuntimeException();
//        }
	}

	

}
