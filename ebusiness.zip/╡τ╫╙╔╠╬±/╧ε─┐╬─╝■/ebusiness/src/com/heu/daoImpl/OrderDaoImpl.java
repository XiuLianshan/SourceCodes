package com.heu.daoImpl;

import java.sql.SQLException;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import com.heu.dao.OrderDao;
import com.heu.domain.Order;
import com.heu.util.TransactionManager;
import com.sun.org.apache.bcel.internal.generic.NEW;
import com.sun.org.apache.regexp.internal.recompile;

public class OrderDaoImpl implements OrderDao {

	@Override
	public Order findOrderByOrderId(String order_id) {
		// TODO Auto-generated method stub
		String sql="select * from orders where id=?";
		try {
			QueryRunner runner=new QueryRunner(TransactionManager.getSource());
			return runner.query(sql, new BeanHandler<Order>(Order.class), order_id);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			throw new RuntimeException();
		}
	}

	@Override
	public List<Order> findOrderByUserId(int user_id) {
		// TODO Auto-generated method stub
		String sql="select * from orders where user_id=?";
		try {
			QueryRunner runner=new QueryRunner(TransactionManager.getSource());
			return runner.query(sql, new BeanListHandler<Order>(Order.class), user_id);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			throw new RuntimeException();
		}
	}

	@Override
	public List<Order> findOrderByState(String state) {
		// TODO Auto-generated method stub
		String sql="select * from orders where state=?";
		try {
			QueryRunner runner=new QueryRunner(TransactionManager.getSource());
			return runner.query(sql, new BeanListHandler<Order>(Order.class), state);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			throw new RuntimeException();
		}
	}

	@Override
	public void updateStateByOrderId(String order_id, String newState) {
		// TODO Auto-generated method stub
		String sql="update orders set state=? where id=?";
		//System.out.println("success!~");
		try {
			QueryRunner runner=new QueryRunner(TransactionManager.getSource());
			runner.update(sql, newState,order_id);
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			throw new RuntimeException();
		}
		
	}

	@Override
	public Order findOrderByOrderIdAndState(String order_id, String state) {
		// TODO Auto-generated method stub
		String sql="select * from orders where id=? and user_id=?";
		try {
			QueryRunner runner=new QueryRunner(TransactionManager.getSource());
			return runner.query(sql, new BeanHandler<Order>(Order.class), order_id,state);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			throw new RuntimeException();
		}
	}

	@Override
	public List<Order> findAllOrders() {
		// TODO Auto-generated method stub
		String sql="select * from orders";
		try {
			QueryRunner runner=new QueryRunner(TransactionManager.getSource());
			return runner.query(sql, new BeanListHandler<Order>(Order.class));
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			throw new RuntimeException();
		}
	}

	@Override
	public void deleteOrderByOrderId(String order_id) {
		// TODO Auto-generated method stub
		String sql1="delete from orders where id=?";
		String sql2="delete from order_item where order_id=?";
		try {
			QueryRunner runner=new QueryRunner(TransactionManager.getSource());
			runner.update(sql2,order_id);
			runner.update(sql1, order_id);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			throw new RuntimeException();
		}
	}

	@Override
	public void deleteOrderItemByOrderId(String order_id) {
		// TODO Auto-generated method stub
		String sql="delete from order_item where order_id=?";
		try {
			QueryRunner runner=new QueryRunner(TransactionManager.getSource());
			runner.update(sql,order_id);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			throw new RuntimeException();
		}
		
	}
	
	@Override
	public void insertOrder(Order order) {
		String sql = "insert into `orders` (user_id,total_price,state)  values (?,?,?)";

		try {
			QueryRunner queryRunner = new QueryRunner(
					TransactionManager.getSource());
			queryRunner.update(sql, order.getUser_id(),order.getTotal_price(),"new");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void updateOrder(Order order) {
		String sql = "update `orders` set  pay_method = ?,message = ? , "
				+ "total_price = ?,receiver_address=?,receiver_name = ?,"
				+ "receiver_tel = ?,post_code = ? where id = ?";
		try {
			QueryRunner queryRunner = new QueryRunner(
					TransactionManager.getSource());
			queryRunner.update(sql,
					order.getPay_method(), order.getMessage(),
					order.getTotal_price(), order.getReceiver_address(),
					order.getReceiver_name(), order.getReceiver_tel(),
					order.getPost_code(), order.getId());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	public Order findOrderByUserId(String user_id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Order findLatestOrder() {
	String sql ="SELECT * from `orders` where id=(select max(id) from `orders`)";
		QueryRunner queryRunner;
		try {
			queryRunner = new QueryRunner(TransactionManager.getSource());
			return queryRunner.query(sql, new BeanHandler<Order>(Order.class));
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	
	}

}
