package com.heu.daoImpl;

import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

import javafx.scene.input.DataFormat;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import com.heu.dao.PersonalOrderDao;
import com.heu.domain.Order;
import com.heu.domain.User;
import com.heu.util.TransactionManager;
import com.mchange.v2.c3p0.ComboPooledDataSource;
import com.mchange.v2.c3p0.impl.C3P0PooledConnectionPool;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Driver;
import com.sun.org.apache.bcel.internal.generic.NEW;

public class PersonalOrderDaoImpl implements PersonalOrderDao {

	@Override
	public List<Order> findPersonalOrdersByTime( Date timeBegin,
			Date timeEnd) {
		// TODO Auto-generated method stub
		String sql="select * from `order` where time between ? and ? ";
		
		
 		try {
 			ComboPooledDataSource dataSource = new ComboPooledDataSource();
 		//	Connection connection = (Connection) DriverManager.getConnection("jdbc:mysql:/localhost:3306/e","root","jiaju19621993");
			
 			QueryRunner runner=new QueryRunner(dataSource);
			return runner.query(sql, new BeanListHandler<Order>(Order.class),timeBegin,timeEnd );
	
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			throw new RuntimeException();
		}
	}
	
	

}
