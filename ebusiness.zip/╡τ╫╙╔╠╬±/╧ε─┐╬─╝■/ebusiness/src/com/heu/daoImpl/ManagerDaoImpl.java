package com.heu.daoImpl;

import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import com.heu.dao.ManagerDao;
import com.heu.domain.Manager;
import com.heu.domain.User;
import com.heu.util.TransactionManager;

public class ManagerDaoImpl implements ManagerDao {

	@Override
	public Manager findManagerByIdAndPwd(String username, String password) {
		// TODO Auto-generated method stub
		String sql="select * from manager where manager_name=? and password=?";
		try {
			QueryRunner runner=new QueryRunner(TransactionManager.getSource());
			return runner.query(sql, new BeanHandler<Manager>(Manager.class), username,password);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			throw new RuntimeException();
		}
	}

	@Override
	public void updatePwdByName(String manager_name,String newPwd) {
		// TODO Auto-generated method stub
		String sql="update manager set password=? where manager_name=?";
		try {
			QueryRunner runner=new QueryRunner(TransactionManager.getSource());
			runner.update(sql, newPwd,manager_name);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			throw new RuntimeException();
		}
	}

	@Override
	public Manager findManagerByName(String manager_name) {
		// TODO Auto-generated method stub
		String sql="select * from manager where manager_name=?";
		try {
			QueryRunner runner=new QueryRunner(TransactionManager.getSource());
			return runner.query(sql, new BeanHandler<Manager>(Manager.class), manager_name);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			throw new RuntimeException();
		}
	}

	@Override
	public void addManager(Manager manager) {
		// TODO Auto-generated method stub
		String sql="insert into manager values(null,?,?,?)";
		try {
			QueryRunner runner=new QueryRunner(TransactionManager.getSource());
			runner.update(sql, manager.getManager_name(),manager.getPassword(),manager.getAuthority());
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			throw new RuntimeException();
		}
	}

	@Override
	public List<Manager> findAllManagers() {
		// TODO Auto-generated method stub
		String sql="select * from manager";
		try {
			QueryRunner runner=new QueryRunner(TransactionManager.getSource());
			return runner.query(sql, new BeanListHandler<Manager>(Manager.class));
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			throw new RuntimeException();
		}
	}

}
