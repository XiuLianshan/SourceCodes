package com.song.bean;

import java.io.Serializable;

public class goods implements Serializable{
	
	public goods(){
		
	}
	private int id;
	private String goods_name;
	private int type1_id;
	private int type2_id;
	private double price;
	private String image_url;
	private int stock;
	private String description;
	private int sold_number;
	private String type1_name;
	private String type2_name;
	
	private int remark_id;
	private String remarks;
	private int star_level;
	private String time;
	private int user_id;
	// n.id,n.remarks,n.star_level,n.time,n.user_id
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getGoods_name() {
		return goods_name;
	}
	public void setGoods_name(String goods_name) {
		this.goods_name = goods_name;
	}
	public int getType1_id() {
		return type1_id;
	}
	public void setType1_id(int type1_id) {
		this.type1_id = type1_id;
	}
	public int getType2_id() {
		return type2_id;
	}
	public void setType2_id(int type2_id) {
		this.type2_id = type2_id;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public String getImage_url() {
		return image_url;
	}
	public void setImage_url(String image_url) {
		this.image_url = image_url;
	}
	public int getStock() {
		return stock;
	}
	public void setStock(int stock) {
		this.stock = stock;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getSold_number() {
		return sold_number;
	}
	public void setSold_number(int sold_number) {
		this.sold_number = sold_number;
	}
	public String getType1_name() {
		return type1_name;
	}

	public void setType1_name(String type1_name) {
		this.type1_name = type1_name;
	}

	public String getType2_name() {
		return type2_name;
	}

	public void setType2_name(String type2_name) {
		this.type2_name = type2_name;
	}
	public int getRemark_id() {
		return remark_id;
	}
	public void setRemark_id(int remark_id) {
		this.remark_id = remark_id;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public int getStar_level() {
		return star_level;
	}
	public void setStar_level(int star_level) {
		this.star_level = star_level;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public int getUser_id() {
		return user_id;
	}
	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}
	
	
}
