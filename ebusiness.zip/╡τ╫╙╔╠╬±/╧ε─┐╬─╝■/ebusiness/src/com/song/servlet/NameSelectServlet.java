package com.song.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.song.bean.goods;
import com.song.service.NameSelectService;



public class NameSelectServlet extends HttpServlet {
	@SuppressWarnings("unchecked")
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		response.setContentType("utf-8");
		//进行模糊搜索
		String name=request.getParameter("selectgood");
		System.out.print(name);
		NameSelectService nameservice=new NameSelectService();
		
		List<goods> namelist= nameservice.searchname(name);
			
	    request.getSession().setAttribute("namelist",namelist);
	    System.out.println(namelist.size());		
	    request.getRequestDispatcher("/namelistshop.jsp").forward(request,response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
       doGet(request, response);
       
	}

}

