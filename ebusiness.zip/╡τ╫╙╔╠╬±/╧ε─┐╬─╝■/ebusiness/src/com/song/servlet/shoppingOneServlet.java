package com.song.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.song.bean.goods;
import com.song.service.shoppingservice;



public class shoppingOneServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		response.setContentType("utf-8");
		shoppingservice goodservice=new shoppingservice();
		
		String type1=request.getParameter("list");
		String type2=request.getParameter("list1");
		String name=request.getParameter("selectgood");
		List<goods> goodlist;
		if(type1!=null&&type2==null){
		 goodlist=goodservice.bigpose(type1);
		 }
		else if(type1==null&&type2==null){
		 goodlist=goodservice.pose(name);
		}else {
			goodlist = goodservice.smallpose(type2);
		}
		
		
	    request.getSession().setAttribute("glist",goodlist);
	    System.out.println(goodlist);
	  response.sendRedirect(request.getContextPath()+"/front/index.jsp");

	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
       doGet(request, response);
       
	}

}
