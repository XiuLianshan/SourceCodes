package com.song.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.song.bean.goods;
import com.song.service.ShoppingInformationServive;
import com.song.service.shoppingservice;

public class ShoppingInformationServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		response.setContentType("utf-8");
      
		String goodname=request.getParameter("goodname");
		System.out.print(goodname);
        ShoppingInformationServive information=new ShoppingInformationServive();
        List<goods> inforlist=information.informationservicedispose(goodname);
        request.getSession().setAttribute("infor",inforlist.get(0));
        //goods p  =null;
        //p = inforlist.get(0);
        //System.out.println(p.getId()+"11111111111"+p.getName());
        //System.out.println(inforlist.get(0).getName());
      //  request.getRequestDispatcher("/information.jsp").forward(request,response);
        	response.sendRedirect(request.getContextPath()+"/front/single.jsp");;
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

			doGet(request, response);
	}

}
