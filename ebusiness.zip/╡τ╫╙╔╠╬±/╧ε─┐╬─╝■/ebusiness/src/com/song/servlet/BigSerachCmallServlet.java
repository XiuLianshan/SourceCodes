package com.song.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.song.bean.Type2;
import com.song.service.CmallTypeService;
import com.song.service.shoppingservice;



public class BigSerachCmallServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
//		request.setCharacterEncoding("utf-8");
//		response.setCharacterEncoding("utf-8");
//		response.setContentType("utf-8");
//		shoppingservice goodservice=new shoppingservice();
//		String type1_name=request.getParameter("list");
//		int typeint_name=Integer.parseInt(type1_name);
//		
//	    CmallTypeService cmall =  new CmallTypeService();
//	    List<CmallType> cmalls =  cmall.searchCmallType(typeint_name);
//	    request.getSession().setAttribute("cmalls", cmalls);
//	    request.getRequestDispatcher("/listshop.jsp").forward(request, response);
////		String type2=request.getParameter("list1");
////		List<Product> goodlist=goodservice.dispose(type1,type2);	
////	    request.getSession().setAttribute("glist",goodlist);
////	    System.out.println(goodlist);		
////	    request.getRequestDispatcher("/listshop.jsp").forward(request,response);

	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
       doGet(request, response);
       
	}

}
