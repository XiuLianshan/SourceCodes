package com.song.Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.song.bean.Type1;
import com.song.bean.goods;

public class GoodsOneDao {
	public List selectshoplist(String type1,String type2,String name){
		
		
    String sql="select m.id,m.goods_name,m.type1_id,m.type2_id,m.price,m.image_url,m.stock,m.description,m.sold_number,n.type_name,z.type_name from `goods` m,`type1` n,`type2` z ";
if(name.equals("")||name==null){
	
    if((type1.equals(" "))&&(type2.equals(" "))){
    	sql += "where (n.id=m.type1_id) and (z.id=m.type2_id) "; 
    		
    }else{
    	if(!type1.equals("")) {
    		sql += "where (m.type1_id = '" + type1 + "') and (m.goods_name LIKE '%"+name+"%') and (n.id='"+type1+"') and (n.id=m.type1_id) and (z.id=m.type2_id)";
    	}
    	if(!type2.equals("")) {

    		sql +=  " and ( m.type2_id = '" + type2 + "' ) and (z.id='"+type2+"')";
    	}
    	sql += ";";
    }}
else{
	if((type1.equals(""))&&(type2.equals(""))&&(!name.equals(""))){
    	sql += "where (n.id=m.type1_id) and (z.id=m.type2_id) and (m.goods_name LIKE '%"+name+"%') "; 
    		
    }else{
    	if(!type1.equals(" ")&&(!name.equals(""))) {
    		sql += "where (m.type1_id = '" + type1 + "') and (m.goods_name LIKE '%"+name+"%') and (n.id='"+type1+"') and (n.id=m.type1_id) and (z.id=m.type2_id)";
    	}
    	if(!type2.equals(" ")&&(!name.equals(""))) {

    		sql +=  " and ( m.type2_id = '" + type2 + "' ) and (z.id='"+type2+"')";
    	}
    	sql += ";";
    }
}


	 List<goods> productsOne = new ArrayList<goods>();	
     try {
	     Class.forName("com.mysql.jdbc.Driver");
	     Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/e","root","jiaju19621993");     
	     PreparedStatement pstmt=conn.prepareStatement(sql);
     
	     ResultSet rs=pstmt.executeQuery();
	 while(rs.next()){
		   goods goods=new goods();
		   //Type1 t =new Type1();
		   int sid=rs.getInt("m.id");
		   goods.setId(sid);
		   String sname=rs.getString("m.goods_name");
		   goods.setGoods_name(sname);
		   int stype1=rs.getInt("m.type1_id");
		   goods.setType1_id(stype1);
		   int stype2=rs.getInt("m.type2_id");
		   goods.setType2_id(stype2);
		   double sprice=rs.getDouble("m.price");
		   goods.setPrice(sprice);
		   String surl=rs.getString("m.image_url");
		   goods.setImage_url(surl);
		   int sstock=rs.getInt("m.stock");
		   goods.setStock(sstock);
		   String sdes=rs.getString("m.description");
		   goods.setDescription(sdes);
		   int snum=rs.getInt("m.sold_number"); 
		   goods.setSold_number(snum);
		   String type1_name=rs.getString("n.type_name");
		   goods.setType1_name(type1_name);
		   String type2_name=rs.getString("z.type_name");
		   goods.setType2_name(type2_name);
		   productsOne.add(goods);
	      
      }
	       rs.close();
           pstmt.close();
           conn.close();
     } catch (ClassNotFoundException e) {
	      // TODO Auto-generated catch block
	       e.printStackTrace();}
       catch (SQLException e) {
	     // TODO Auto-generated catch block
	       e.printStackTrace();}
     return productsOne;
    }

	public List<goods> selectshoplist1(String name) {

		
	    String sql="select id,goods_name,type1_id,type2_id,price,image_url,stock,description,sold_number from `goods`  ";
	    sql=sql+"where goods_name LIKE '%"+name+"%'";
	    List<goods> productsOne = new ArrayList<goods>();	
	     try {
		     Class.forName("com.mysql.jdbc.Driver");
		     Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/e","root","jiaju19621993");     
		     PreparedStatement pstmt=conn.prepareStatement(sql);
	     
		     ResultSet rs=pstmt.executeQuery();
		 while(rs.next()){
			   goods goods=new goods();
			   //Type1 t =new Type1();
			   int sid=rs.getInt("id");
			   goods.setId(sid);
			   String sname=rs.getString("goods_name");
			   goods.setGoods_name(sname);
			   int stype1=rs.getInt("type1_id");
			   goods.setType1_id(stype1);
			   int stype2=rs.getInt("type2_id");
			   goods.setType2_id(stype2);
			   double sprice=rs.getDouble("price");
			   goods.setPrice(sprice);
			   String surl=rs.getString("image_url");
			   goods.setImage_url(surl);
			   int sstock=rs.getInt("stock");
			   goods.setStock(sstock);
			   String sdes=rs.getString("description");
			   goods.setDescription(sdes);
			   int snum=rs.getInt("sold_number"); 
			   goods.setSold_number(snum);
			   productsOne.add(goods);
		      
	      }
		       rs.close();
	           pstmt.close();
	           conn.close();
	     } catch (ClassNotFoundException e) {
		      // TODO Auto-generated catch block
		       e.printStackTrace();}
	       catch (SQLException e) {
		     // TODO Auto-generated catch block
		       e.printStackTrace();}
	     return productsOne;
	}

	public List<goods> selectshoplist2(String type1) {
		 String sql="select id,goods_name,type1_id,type2_id,price,image_url,stock,description,sold_number from `goods`  ";
		    sql=sql+"where type1_id = "+type1;
		    List<goods> productsOne = new ArrayList<goods>();	
		     try {
			     Class.forName("com.mysql.jdbc.Driver");
			     Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/e","root","jiaju19621993");     
			     PreparedStatement pstmt=conn.prepareStatement(sql);
		     
			     ResultSet rs=pstmt.executeQuery();
			 while(rs.next()){
				   goods goods=new goods();
				   //Type1 t =new Type1();
				   int sid=rs.getInt("id");
				   goods.setId(sid);
				   String sname=rs.getString("goods_name");
				   goods.setGoods_name(sname);
				   int stype1=rs.getInt("type1_id");
				   goods.setType1_id(stype1);
				   int stype2=rs.getInt("type2_id");
				   goods.setType2_id(stype2);
				   double sprice=rs.getDouble("price");
				   goods.setPrice(sprice);
				   String surl=rs.getString("image_url");
				   goods.setImage_url(surl);
				   int sstock=rs.getInt("stock");
				   goods.setStock(sstock);
				   String sdes=rs.getString("description");
				   goods.setDescription(sdes);
				   int snum=rs.getInt("sold_number"); 
				   goods.setSold_number(snum);
				   productsOne.add(goods);
			      
		      }
			       rs.close();
		           pstmt.close();
		           conn.close();
		     } catch (ClassNotFoundException e) {
			      // TODO Auto-generated catch block
			       e.printStackTrace();}
		       catch (SQLException e) {
			     // TODO Auto-generated catch block
			       e.printStackTrace();}
		     return productsOne;
	}

	public List<goods> selectshoplist3(String type2) {
		 String sql="select id,goods_name,type1_id,type2_id,price,image_url,stock,description,sold_number from `goods`  ";
		    sql=sql+"where type2_id = "+type2;
		    List<goods> productsOne = new ArrayList<goods>();	
		     try {
			     Class.forName("com.mysql.jdbc.Driver");
			     Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/e","root","jiaju19621993");     
			     PreparedStatement pstmt=conn.prepareStatement(sql);
		     
			     ResultSet rs=pstmt.executeQuery();
			 while(rs.next()){
				   goods goods=new goods();
				   //Type1 t =new Type1();
				   int sid=rs.getInt("id");
				   goods.setId(sid);
				   String sname=rs.getString("goods_name");
				   goods.setGoods_name(sname);
				   int stype1=rs.getInt("type1_id");
				   goods.setType1_id(stype1);
				   int stype2=rs.getInt("type2_id");
				   goods.setType2_id(stype2);
				   double sprice=rs.getDouble("price");
				   goods.setPrice(sprice);
				   String surl=rs.getString("image_url");
				   goods.setImage_url(surl);
				   int sstock=rs.getInt("stock");
				   goods.setStock(sstock);
				   String sdes=rs.getString("description");
				   goods.setDescription(sdes);
				   int snum=rs.getInt("sold_number"); 
				   goods.setSold_number(snum);
				   productsOne.add(goods);
			      
		      }
			       rs.close();
		           pstmt.close();
		           conn.close();
		     } catch (ClassNotFoundException e) {
			      // TODO Auto-generated catch block
			       e.printStackTrace();}
		       catch (SQLException e) {
			     // TODO Auto-generated catch block
			       e.printStackTrace();}
		     return productsOne;
	}


}

