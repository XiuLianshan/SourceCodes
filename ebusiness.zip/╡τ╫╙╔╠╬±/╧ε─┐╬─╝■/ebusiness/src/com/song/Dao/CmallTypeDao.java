package com.song.Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.song.bean.Type2;

public class CmallTypeDao{
	
	public List selectBigTypelist(){
    String sql="select id,type_name,type1_id from `type2`";
    
	 List<Type2> cmalltype = new ArrayList<Type2>();	
     try {
	     Class.forName("com.mysql.jdbc.Driver");
	     Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/e","root","jiaju19621993");     
	     PreparedStatement pstmt=conn.prepareStatement(sql);
     
	     ResultSet rs=pstmt.executeQuery();
	 while(rs.next()){
		   Type2 type2=new Type2();
		   int sid=rs.getInt("id");
		   type2.setId(sid);
		   
		   String sname=rs.getString("type_name");
		   type2.setType_name(sname);
		   
		   int sbigid=rs.getInt("type1_id");
		   type2.setType1_id(sbigid);
		   
		   cmalltype.add(type2);
      }
	       rs.close();
           pstmt.close();
           conn.close();
     } catch (ClassNotFoundException e) {
	      // TODO Auto-generated catch block
	       e.printStackTrace();}
       catch (SQLException e) {
	     // TODO Auto-generated catch block
	       e.printStackTrace();}
       return cmalltype;
    }
	  
}

