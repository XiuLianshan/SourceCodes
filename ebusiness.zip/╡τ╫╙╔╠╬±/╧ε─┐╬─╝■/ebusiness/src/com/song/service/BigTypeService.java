package com.song.service;

import java.util.List;


import com.song.Dao.BigTypeDao;
import com.song.bean.Type1;


public class BigTypeService {
	
	 	public List searchBigType(){
	 	   BigTypeDao bigtypedao=new BigTypeDao();
	 	   List<Type1> bigtypelist=bigtypedao.selectBigTypelist();
	 	   return bigtypelist;
	 	}
	 }
