package com.song.service;

import java.util.List;

import com.song.Dao.GoodsOneDao;
import com.song.Dao.InformationDao;
import com.song.bean.goods;

public class ShoppingInformationServive {
		public List informationservicedispose(String name){
			InformationDao dao=new InformationDao();
		    List<goods> list=dao.selectinformation(name);
		    return list;
		}

}
