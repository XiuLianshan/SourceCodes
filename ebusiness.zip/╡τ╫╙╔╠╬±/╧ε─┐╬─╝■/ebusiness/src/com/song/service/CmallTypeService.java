package com.song.service;

import java.util.List;

import com.song.Dao.CmallTypeDao;
import com.song.bean.Type2;


public class CmallTypeService {
	
	 	public List searchCmallType(){
	 		CmallTypeDao cmalltypedao=new CmallTypeDao();
	 	    List<Type2> cmalltypelist=cmalltypedao.selectBigTypelist();
	 	    return cmalltypelist;
	 	}
	 }
