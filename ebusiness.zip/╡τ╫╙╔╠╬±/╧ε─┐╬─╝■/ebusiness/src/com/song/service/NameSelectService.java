package com.song.service;

import java.util.List;

import com.song.Dao.NameSelectDao;
import com.song.bean.goods;


public class NameSelectService {
	
	 	public List searchname(String name1){
	 	   NameSelectDao nameselectdao=new NameSelectDao();
	 	   List<goods> namelist=nameselectdao.selectnamelist(name1);
	 
	 	   return namelist;
	 	}


	 }
