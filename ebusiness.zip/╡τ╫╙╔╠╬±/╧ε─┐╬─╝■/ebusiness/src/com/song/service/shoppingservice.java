 package com.song.service;

import java.util.List;

import com.song.Dao.GoodsOneDao;
import com.song.bean.goods;

public class shoppingservice {
	public List<goods> dispose(String t1,String t2,String name){
	   GoodsOneDao dao=new GoodsOneDao();
	   List<goods> list=dao.selectshoplist(t1,t2,name);
	   return list;
	}
	
	public List<goods> pose(String name){
		   GoodsOneDao dao=new GoodsOneDao();
		   List<goods> list=dao.selectshoplist1(name);
		   return list;
		}

	public List<goods> bigpose(String type1) {
		 GoodsOneDao dao=new GoodsOneDao();
		   List<goods> list=dao.selectshoplist2(type1);
		   return list;
	}

	public List<goods> smallpose(String type2) {
		GoodsOneDao dao=new GoodsOneDao();
		   List<goods> list=dao.selectshoplist3(type2);
		   return list;
	}
}
