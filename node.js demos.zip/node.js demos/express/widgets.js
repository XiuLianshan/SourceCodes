var express = require('express'),
    http = require ('http') ,
    app = express();
var path = require('path');
var favicon = require('static-favicon');
var logger = require('morgan');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
var routes = require('./routes');
var map = require('./map/maproute');
var mongoose = require('mongoose');
//connect to mongodb
mongoose.connect('mongodb://127.0.0.1/WidgetDB');
mongoose.connection.on('open',function(){
	console.log('connected to mongoose');
});

console.log(routes.index);
app.use(favicon());
app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended:true}));
app.use(cookieParser());
app.use(express.static(__dirname, 'public'));
app.use(express.Router());
app.use(function(req,res,next){
	throw new Error(req.url + 'not found');	
});
app.use(function(err,req,res,next){
	console.log(err);
	res.send(err.message);	
});
app.get('/',routes);

var prefixes = ['widget'];

//map route to controller

prefixes.forEach(function(prefix){
	map.mapRoute(app,prefix);
});


http.createServer(app).listen(3000);
console.log('done');
