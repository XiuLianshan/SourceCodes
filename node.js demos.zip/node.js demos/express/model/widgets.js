var mongoose = require('mongoose');
var Schema = mongoose.Schema,
	ObjectId = Schema.ObjectId;
// create a widget model
var widget = new Schema({
	sn:{type:String,required:true,trim:true,unique:true},
	name:{type:String,required:true,trim:true},
	desc:String,
	price:Number
});
module.exports = mongoose.model('Widget',widget);
