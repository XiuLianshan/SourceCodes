var express = require('express'),
    http = require ('http') ,
    app = express();
var path = require('path');
var favicon = require('static-favicon');
var logger = require('morgan');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');


app.use(favicon());
app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended:true}));
app.use(cookieParser());
app.use(express.static(__dirname, 'public'));
app.use(express.Router());



// in memory data store
var widgets = [
	{
	id : 1,
	name : 'my first widget',
	price : 100.00,
	descr : 'a widget beyond price'
}
]

//index for /widgets/

app.get('/widgets/',function(req,res){
	res.send(widgets);
});

// show a specific widget

app.get('/widgets/:id',function(req,res){
	var indx = parseInt(req.params.id) - 1;
	if(!widgets[indx])
		res.send('there is no widget with id of ' + req.params.id);
	else
		res.send(widgets[indx]);
});

//add a widget 
app.post('/widgets/add',function(req,res){
	var indx = widgets.length - 1 ;
	widgets[widgets.length ] = {
	id : indx,
	name : req.body.widgetname,
	price : parseFloat(req.body.widgetprice),
	descr : req.body.widgetdesc			
};
console.log(widgets[indx - 1]);
res.send('widget ' + req.body.widgetname + ' added with id '+ indx + ' price ' + req.body.widgetprice);
});
// delete a widget

app.del('/widgets/:id/:delete',function(req,res){
	var indx = req.params.id -1;
	delete widgets[indx];
	console.log('deleted ' + req.params.id);
});

//update

app.put('/widgets/:id/update',function(req,res){
	var indx = parseInt(req.params.id-1);
	widgets[indx] = {
		id : indx,
		name : req.body.widgetname,
		price : parseFloat(req.body.widgetprice),
		descr : req.body.widgetderc		
};
	console.log(widgets[indx]);
	res.send('updated ' + req.params.id);
	});


http.createServer(app).listen(3000);
console.log('done');
