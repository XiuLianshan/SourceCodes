/*var widgets = [{
	id : 1,
	name : "hello widget",
	price : 22.0}]*/

var Widget = require('../model/widget.js');
//index listing of widget at /widgets/
exports.index = function(req,res){
	//res.send(widgets);
	Widget.find({},function(err,docs){
	console.log(docs);
	res.render('widgets/index',{title:'Widgets',widgets:docs});
});


};

// display new widget form
exports.new = function(req,res){
	/*var indx = widgets.length + 1;
	widgets[widgets.length] = {
		id :indx,
		name : req.body.widgetname,
		price : parseFloat(req.body.widgetprice),
		desc : req.body.widgetdesc	*/	
	console.log(req.url);
	var filePath = require('path').normalize(__dirname + "/../public/widgets/new.html");	
	res.sendFile(filePath);
	};


//console.log(widgets[indx-1]);
////res.render('widgets/added',{titls:'widget added',widget:widgets[indx - 1]});
/////	res.send('displaying new widget form');};

//add a widget 
exports.create = function(req,res){
	/*var indx = widgets.length - 1 ;
	widgets[widgets.length ] = {
	id : indx,
	name : req.body.widgetname,
	price : parseFloat(req.body.widgetprice),
	descr : req.body.widgetdesc		*///
	var widget = {
		sn:req.body.widgetsn,
		name:req.body.widgetname,
		price:parseFloat(req.body.widgetprice),
		desc:req.body.widgetdesc
	};
	var widgetObj = new Widget(widget);
	widgetObj.save(function(err,data){
		if(err) res.send(err);
		else {
		console.log(data);
		res.render('widgets/added',{title:'Widget Added',widget:widget});
}
});	
};
/*console.log(widgets[indx - 1]);
res.send('widget ' + req.body.widgetname + ' added with id '+ indx + ' price ' + req.body.widgetprice);
};*/

// show a widget
exports.show = function(req,res){
	/*var indx = parseInt(req.params.id) - 1;
	if(!widgets[indx]) 
		res.send('there is no widget with id of ' + req.params.id);
	else
		res.send(widgets[indx]);*/

	var sn = req.params.sn;
	Widget.findOne({sn:sn},function(err,doc){
		if(err)
			res.send('there is no widget with sn of ' + sn);
		else 
			res.render('widgets/show',{title:'Widgets Show',widget:doc});
});
	
};

//delete a widget
exports.destroy = function(req,res){

	/*var indx = req.params.d -1 ;
	delete widgets[indx];
	console.log('deleted ' + req.params.id);
	res.send('deleted ' + req.params.id);*/

	var sn = req.params.sn;
	Widget.remove({sn:sn},function(err){
		if(err)  res.send('there is no widget with sn of ' + sn);
		else {
			console.log('deleted' + sn);
			res.send('deleted' + sn);
}
});

};

//display edit form

exports.edit = function(req,res){
	//res.send('display edit form');
	var sn = req.params.sn;
	Widget.findOne({sn:sn},function(err,doc){
		console.log(doc);
		if(err) res.send('there is no widget with sn of ' + sn);
		else res.render('widgets/edit',{title:'Edit Widget',widget : doc});
});

};

//update a widget

exports.update = function(req,res){
	/*var indx = parseInt(req.params.id) - 1;
	widgets[indx] = {
		id :indx,
		name : req.body.widgetname,
		price:parseFloat(req.body.widgetprice)
	};
	console.log(widgets[indx]);
	res.send('updated ' + req.params.id);*/
	var sn = req.params.sn;
	var widget = {
		sn:req.body.widgetsn,
		name:req.body.widgetname,
		price:parseFloat(req.body.widgetprice),
		desc:req.body.widgetdesc};
	Widget.update({sn:sn},widget,function(err){
		if(err) res.send('problem occured with update ' + err);
		else res.render('widgets/added',{title:'widget edited',widget:widget});
});
	
};










