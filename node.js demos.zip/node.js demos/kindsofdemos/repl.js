repl = require("repl");
repl.start(">",null,null,null,true);
