/**
 * Created by xiulianshan on 3/8/16.
 */
var connect = require('connect');
var http = require('http');
var morgan = require('morgan');
var sfavicon = require('serve-favicon');
var app = connect()
    //.use(sfavicon())
    .use(morgan())
    .use(function(req,res){
        res.end('hello world.');
    });

http.createServer(app).listen(8124);