var http = require('http');
var fs = require('fs');
//create http server
http.createServer(function(req,res){
//open and read in hello.js
fs.readFile('hello.js','utf8',function(err,data){
res.writeHead(200,{'Content-Type':'text/plain'});
if(err)
res.write('could not find or open for reading\n');
else
// if no error ,write js file client
res.write(data);
res.end();
});
}).listen(8124,function(){
console.log('bound to port 8124');});
console.log('Server running on 8124');
