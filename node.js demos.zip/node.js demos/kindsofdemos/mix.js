var connect = require('connect'),
    http = require('http'),
    fs = require('fs'),
    crossroads = require('crossroads'),
    morgan = require('morgan'),
    statics = require('serve-static'),
    httpProxy = require('http-proxy'),
    base = __dirname;
var proxy = httpProxy.createProxyServer();
http.createServer(function(req,res){
	if(req.url.match(/^\/node\//))
		proxy.web(req,res,{target:'http://localhost:8000'});
	else
		proxy.web(req,res,{target:'http://localhost:8124'});
}).listen(9000);
crossroads.addRoute('/node/{id}',function(id){
		console.log('accessed node ' + id);});
http.createServer(function(req,res){
	crossroads.parse(req.url);
	res.end('that is all!');}).listen(8000);
http.createServer(connect()
		.use(morgan('dev'))
		.use(statics(base))).listen(8124);
console.log('i am done');
