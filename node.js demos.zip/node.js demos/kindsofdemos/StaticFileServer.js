/**
 * Created by xiulianshan on 3/8/16.
 */
var http = require('http'),
    path = require('path'),
    fs = require('fs'),
    mime = require('mime');
   // base = '/home/xiulianshan/working';
http.createServer(function (req, res) {
    pathname = __dirname + req.url;
    console.log(pathname);
    //fs.exists(pathname, function (exists) {
    fs.stat(pathname, function (err, stats) {
        if (/*!exists*/err) {
            res.writeHead(404);
            res.write('bad request 404');
            res.end();
        } else if (stats.isFile()) {
            var type = mime.lookup(pathname);
            console.log(type);
            res.setHeader('content-type', type);
            res.statusCode = 200;

            var file = fs.createReadStream(pathname);
            file.on('open', function () {
                file.pipe(res);
            });
            file.on('error', function (err) {
                console.log(err);
            });
        } else {
            res.writeHead(403);
            res.write('directory access is forbidden');
            res.end();
        }
    });
}).listen(8124);
console.log('server running at 8124\n');