var http = require('http'),
	url = require('url'),
	fs = require('fs'),
	mime = require('mime');
function processRange(res,ranges,len){
	var start ,end;
	//get start and end from ranges
	var rangeArray = ranges.split('-');
	
	start = parseInt(rangeArray[0].substr(6));
	end = parseInt(rangeArray[1]);
	
	if(isNaN(start))  start = 0;
	if(isNaN(end))  end = len - 1;

	//if start is longer than resource
	if(start > len - 1){
		res.setHeader('Content-Range','bytes */' + len);
		res.writeHead(416);
		res.end();
	}
	// end can not longer than the resource
	if(end > len - 1){
		end = len - 1;
	}
	return {start:start,end : end};
}

http.createServer(function(req,res){
	pathname = __dirname + '/public'+req.url;
	fs.stat(pathname,function(err,stats){
		if(err) {
			res.writeHead(404);
			res.write('bad request 404\n');
			res.end();
		}else if(stats.isFile()){
			var opt = {};
			res.statusCode = 200;
			var len = stats.size;
			if(req.headers.range){
				len = opt.end - opt.start + 1;
				res.statusCode = 206;
				var ctstr = 'bytes ' + opt.start + '-' + opt.end + '/' + stats.size;
				res.setHeader('Content-Range',ctsrt);
			}
			console.log('len ' + len);
			res.setHeader('Content-Length',len);
			var type = mime.lookup(pathname);
			res.setHeader('content-type',type);
			res.setHeader('Accept-Ranges','bytes');
			var file = fs.createReadStream(pathname,opt);
			file.on('open',function(){
				file.pipe(res);
			});
			file.on('error',function(){
				console.log(err);
			});
		}else{
			res.writeHead(403);
			res.write('directory access is forbidden');
			res.end();
		}
	});	

}).listen(8124);
console.log('server running at 8124');
